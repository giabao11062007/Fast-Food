using System.Diagnostics;
using FastFood.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FastFood.Controllers
{
    public class HomeController : Controller
    {
        private readonly FastFoodContext _context;

        public HomeController(FastFoodContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            // Checklist: Menu đã lấy theo Category, Sản phẩm tồn kho > 0, Món nổi bật, Combo
            var model = new HomeViewModel
            {
                Categories = await _context.Categories.ToListAsync(),
                FeaturedProducts = await _context.Products
                    .Include(p => p.Category)
                    .Where(p => p.Quantity > 0 && p.IsFeatured)
                    .Take(8)
                    .ToListAsync(),
                Combos = await _context.Products
                    .Include(p => p.Category)
                    .Where(p => p.Quantity > 0 && p.IsCombo)
                    .Take(6)
                    .ToListAsync()
            };

            return View(model);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
