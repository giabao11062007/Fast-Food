using System.Security.Claims;
using FastFood.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FastFood.Controllers
{
    public class AccountController : Controller
    {
        private readonly FastFoodContext _context;

        public AccountController(FastFoodContext context)
        {
            _context = context;
        }

        private int GetCurrentUserId()
        {
            var userIdStr = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            int.TryParse(userIdStr, out int userId);
            return userId;
        }

        // GET: /Account/Login
        public IActionResult Login(string? returnUrl = null)
        {
            if (User.Identity?.IsAuthenticated ?? false)
            {
                return RedirectToAction("Index", "Home");
            }

            ViewBag.ReturnUrl = returnUrl;
            return View(new LoginViewModel { ReturnUrl = returnUrl });
        }

        // POST: /Account/Login
        // Checklist: "Đăng nhập thất bại, có hiển thị thông báo?", "Đăng nhập thành công, đổi icon & hiển thị tên"
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Username == model.Username && u.Password == model.Password);

            if (user == null)
            {
                // Thông báo lỗi khi đăng nhập thất bại
                ModelState.AddModelError(string.Empty, "Tên đăng nhập hoặc mật khẩu không chính xác.");
                TempData["Error"] = "Đăng nhập thất bại: Tên đăng nhập hoặc mật khẩu không chính xác!";
                return View(model);
            }

            // Create Claims for Cookie Authentication
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
                new Claim(ClaimTypes.Name, user.FullName),
                new Claim(ClaimTypes.Role, user.Role),
                new Claim("Username", user.Username),
                new Claim(ClaimTypes.Email, user.Email)
            };

            var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var authProperties = new AuthenticationProperties
            {
                IsPersistent = model.RememberMe,
                ExpiresUtc = model.RememberMe ? DateTimeOffset.UtcNow.AddDays(7) : DateTimeOffset.UtcNow.AddHours(2)
            };

            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(claimsIdentity),
                authProperties);

            TempData["Success"] = $"Chào mừng trở lại, {user.FullName}!";

            if (user.Role == "Admin")
            {
                return RedirectToAction("Index", "Dashboard", new { area = "Admin" });
            }

            if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
            {
                return Redirect(model.ReturnUrl);
            }

            return RedirectToAction("Index", "Home");
        }

        // GET: /Account/Register
        public IActionResult Register()
        {
            if (User.Identity?.IsAuthenticated ?? false)
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }

        // POST: /Account/Register
        // Checklist:
        // - Data Annotation: độ dài, trường bắt buộc, kiểu dữ liệu, giá trị dữ liệu
        // - Kiểm tra trùng thông tin với tài khoản đã có (Username, Email)
        // - Đăng ký thất bại, có hiển thị thông báo
        // - Đăng ký thành công, có redirect về trang Đăng nhập
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid)
            {
                TempData["Error"] = "Vui lòng kiểm tra lại thông tin nhập vào theo đúng định dạng.";
                return View(model);
            }

            // Check duplicate Username
            if (await _context.Users.AnyAsync(u => u.Username.ToLower() == model.Username.Trim().ToLower()))
            {
                ModelState.AddModelError("Username", "Tên đăng nhập này đã được sử dụng. Vui lòng chọn tên khác.");
                TempData["Error"] = "Tên đăng nhập đã tồn tại trong hệ thống!";
                return View(model);
            }

            // Check duplicate Email
            if (await _context.Users.AnyAsync(u => u.Email.ToLower() == model.Email.Trim().ToLower()))
            {
                ModelState.AddModelError("Email", "Địa chỉ email này đã được đăng ký tài khoản khác.");
                TempData["Error"] = "Email đã tồn tại trong hệ thống!";
                return View(model);
            }

            // Create new customer account
            var newUser = new User
            {
                Username = model.Username.Trim(),
                Password = model.Password, // Lưu mật khẩu
                FullName = model.FullName.Trim(),
                Email = model.Email.Trim(),
                Phone = model.Phone.Trim(),
                Address = model.Address.Trim(),
                Role = "Customer",
                CreatedAt = DateTime.Now
            };

            _context.Users.Add(newUser);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Đăng ký tài khoản thành công! Vui lòng đăng nhập để tiếp tục mua hàng.";
            return RedirectToAction("Login");
        }

        // POST: /Account/Logout
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Clear();
            TempData["Success"] = "Bạn đã đăng xuất tài khoản thành công.";
            return RedirectToAction("Index", "Home");
        }

        // GET: /Account/Profile
        // Checklist: "Hồ sơ khách hàng"
        [Authorize]
        public async Task<IActionResult> Profile()
        {
            int userId = GetCurrentUserId();
            var user = await _context.Users.FindAsync(userId);
            if (user == null)
            {
                return RedirectToAction("Login");
            }

            var model = new ProfileViewModel
            {
                UserId = user.UserId,
                Username = user.Username,
                FullName = user.FullName,
                Email = user.Email,
                Phone = user.Phone ?? string.Empty,
                Address = user.Address ?? string.Empty
            };

            return View(model);
        }

        // POST: /Account/Profile
        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile(ProfileViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            int userId = GetCurrentUserId();
            var user = await _context.Users.FindAsync(userId);
            if (user == null)
            {
                return RedirectToAction("Login");
            }

            // Check duplicate email with another user
            if (await _context.Users.AnyAsync(u => u.Email.ToLower() == model.Email.Trim().ToLower() && u.UserId != userId))
            {
                ModelState.AddModelError("Email", "Email này đã được sử dụng bởi tài khoản khác.");
                TempData["Error"] = "Email đã tồn tại!";
                return View(model);
            }

            user.FullName = model.FullName.Trim();
            user.Email = model.Email.Trim();
            user.Phone = model.Phone?.Trim();
            user.Address = model.Address?.Trim();

            await _context.SaveChangesAsync();
            TempData["Success"] = "Cập nhật hồ sơ thông tin cá nhân thành công!";
            return RedirectToAction("Profile");
        }

        // GET: /Account/OrderHistory
        // Checklist:
        // - "Kích vào link Lịch sử giao dịch, có chuyển tới trang Lịch sử giao dịch không?"
        // - "Danh sách giao dịch: có phải chỉ lấy các đơn hàng của khách hàng không (hay có cả đơn hàng của khách khác)?" (Nâng cao)
        [Authorize]
        public async Task<IActionResult> OrderHistory()
        {
            int userId = GetCurrentUserId();

            // CHỈ LẤY CÁC ĐƠN HÀNG CỦA KHÁCH HÀNG ĐANG ĐĂNG NHẬP (Checklist nâng cao)
            var orders = await _context.Orders
                .Include(o => o.OrderDetails)
                    .ThenInclude(od => od.Product)
                .Where(o => o.UserId == userId)
                .OrderByDescending(o => o.OrderDate)
                .ToListAsync();

            return View(orders);
        }

        // GET: /Account/OrderDetail/5
        // Checklist:
        // - "Xem chi tiết: có hiển thị Hóa đơn mua hàng (giống trang Detail của quản lý đơn hàng)?" (Nâng cao)
        // - "Tạo chung 1 Partial View dùng cho cả trang Admin và Customer" (Nâng cao: Reuses _InvoicePartial)
        [Authorize]
        public async Task<IActionResult> OrderDetail(int id)
        {
            int userId = GetCurrentUserId();
            string? userRole = User.FindFirst(ClaimTypes.Role)?.Value;

            var order = await _context.Orders
                .Include(o => o.User)
                .Include(o => o.OrderDetails)
                    .ThenInclude(od => od.Product)
                        .ThenInclude(p => p!.Category)
                .FirstOrDefaultAsync(o => o.OrderId == id);

            if (order == null)
            {
                return NotFound();
            }

            // Customer can only view their own order, Admin can view any order
            if (userRole != "Admin" && order.UserId != userId)
            {
                TempData["Error"] = "Bạn không có quyền xem đơn hàng của khách hàng khác!";
                return RedirectToAction("OrderHistory");
            }

            return View(order);
        }
    }
}
