using FastFood.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FastFood.Controllers
{
    public class ProductController : Controller
    {
        private readonly FastFoodContext _context;

        public ProductController(FastFoodContext context)
        {
            _context = context;
        }

        // GET: /Product or /Product/Index
        // Supports: Search keyword, Category filter, Price range, Sort, Pagination
        public async Task<IActionResult> Index(
            int? categoryId, 
            string? keyword, 
            decimal? minPrice, 
            decimal? maxPrice, 
            string? sortBy, 
            int page = 1)
        {
            const int pageSize = 8; // 8 items per page for clean grid

            // Checklist requirement: "Sản phẩm hiển thị trên trang Product Category có số lượng tồn > 0"
            var query = _context.Products
                .Include(p => p.Category)
                .Where(p => p.Quantity > 0);

            // Filter by Category
            if (categoryId.HasValue && categoryId.Value > 0)
            {
                query = query.Where(p => p.CategoryId == categoryId.Value);
            }

            // Search by Keyword
            if (!string.IsNullOrWhiteSpace(keyword))
            {
                string searchLower = keyword.Trim().ToLower();
                query = query.Where(p => p.ProductName.ToLower().Contains(searchLower) 
                                      || (p.Description != null && p.Description.ToLower().Contains(searchLower)));
            }

            // Filter by Price range
            if (minPrice.HasValue && minPrice.Value > 0)
            {
                query = query.Where(p => p.Price >= minPrice.Value);
            }
            if (maxPrice.HasValue && maxPrice.Value > 0)
            {
                query = query.Where(p => p.Price <= maxPrice.Value);
            }

            // Sorting
            switch (sortBy)
            {
                case "price_asc":
                    query = query.OrderBy(p => p.Price);
                    break;
                case "price_desc":
                    query = query.OrderByDescending(p => p.Price);
                    break;
                case "rating_desc":
                    query = query.OrderByDescending(p => p.Rating);
                    break;
                case "name_asc":
                    query = query.OrderBy(p => p.ProductName);
                    break;
                default:
                    query = query.OrderByDescending(p => p.IsFeatured).ThenByDescending(p => p.SoldQuantity);
                    break;
            }

            // Pagination (Checklist requirement: "Đã phân trang kết quả tìm kiếm chưa")
            int totalCount = await query.CountAsync();
            var products = await query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var categories = await _context.Categories.ToListAsync();

            var model = new MenuViewModel
            {
                Products = products,
                Categories = categories,
                CurrentCategoryId = categoryId,
                SearchKeyword = keyword,
                MinPrice = minPrice,
                MaxPrice = maxPrice,
                SortBy = sortBy,
                CurrentPage = page,
                PageSize = pageSize,
                TotalCount = totalCount
            };

            return View(model);
        }

        // GET: /Product/Detail/5
        public async Task<IActionResult> Detail(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products
                .Include(p => p.Category)
                .FirstOrDefaultAsync(p => p.ProductId == id);

            if (product == null)
            {
                return NotFound();
            }

            // Related products in the same category (Quantity > 0, excluding current product)
            var relatedProducts = await _context.Products
                .Where(p => p.CategoryId == product.CategoryId && p.ProductId != product.ProductId && p.Quantity > 0)
                .Take(4)
                .ToListAsync();

            ViewBag.RelatedProducts = relatedProducts;
            ViewBag.ShowBuyButton = true; // Reusing _ProductDetailPartial with buy button!

            return View(product);
        }
    }
}
