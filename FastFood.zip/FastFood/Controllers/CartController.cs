using System.Security.Claims;
using FastFood.Helpers;
using FastFood.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FastFood.Controllers
{
    public class CartController : Controller
    {
        private const string CartSessionKey = "Cart";
        private readonly FastFoodContext _context;

        public CartController(FastFoodContext context)
        {
            _context = context;
        }

        private List<CartItem> GetCart()
        {
            return HttpContext.Session.Get<List<CartItem>>(CartSessionKey) ?? new List<CartItem>();
        }

        private void SaveCart(List<CartItem> cart)
        {
            HttpContext.Session.Set(CartSessionKey, cart);
        }

        // GET: /Cart or /Cart/Index
        public IActionResult Index()
        {
            var cart = GetCart();
            return View(cart);
        }

        // POST: /Cart/AddToCart
        [HttpPost]
        public async Task<IActionResult> AddToCart(int productId, int quantity = 1, string? returnUrl = null)
        {
            var product = await _context.Products.FindAsync(productId);
            if (product == null)
            {
                TempData["Error"] = "Không tìm thấy món ăn yêu cầu.";
                return RedirectToAction("Index", "Product");
            }

            if (product.Quantity <= 0)
            {
                TempData["Error"] = $"Món ăn '{product.ProductName}' hiện đã hết hàng.";
                return RedirectToAction("Detail", "Product", new { id = productId });
            }

            var cart = GetCart();
            var item = cart.FirstOrDefault(x => x.ProductId == productId);

            if (item != null)
            {
                // Checklist: Kiểm tra số lượng tồn (không cho > số lượng tồn)
                if (item.Quantity + quantity > product.Quantity)
                {
                    item.Quantity = product.Quantity;
                    TempData["Warning"] = $"Đã cập nhật tối đa số lượng tồn kho ({product.Quantity} phần) cho '{product.ProductName}'.";
                }
                else
                {
                    item.Quantity += quantity;
                    TempData["Success"] = $"Đã thêm '{product.ProductName}' vào giỏ hàng thành công!";
                }
                item.StockQuantity = product.Quantity;
            }
            else
            {
                int addQty = Math.Min(quantity, product.Quantity);
                cart.Add(new CartItem
                {
                    ProductId = product.ProductId,
                    ProductName = product.ProductName,
                    Price = product.Price,
                    ImageUrl = product.ImageUrl,
                    Quantity = addQty > 0 ? addQty : 1,
                    StockQuantity = product.Quantity
                });
                TempData["Success"] = $"Đã thêm '{product.ProductName}' vào giỏ hàng thành công!";
            }

            SaveCart(cart);

            // Checklist requirement: "Sau khi thêm hàng vào giỏ hàng, có chuyển tới trang giỏ hàng hoặc trang Product Category không?"
            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            return RedirectToAction("Index");
        }

        // POST: /Cart/UpdateQuantity
        // Checklist: "Đã kiểm tra số lượng hàng khi tăng giảm số lượng? (không cho nhập < 0, và > số lượng tồn)"
        [HttpPost]
        public async Task<IActionResult> UpdateQuantity(int productId, int quantity)
        {
            var cart = GetCart();
            var item = cart.FirstOrDefault(x => x.ProductId == productId);
            if (item != null)
            {
                var product = await _context.Products.FindAsync(productId);
                int maxStock = product?.Quantity ?? item.StockQuantity;

                if (quantity <= 0)
                {
                    cart.Remove(item);
                    TempData["Success"] = $"Đã xóa món '{item.ProductName}' khỏi giỏ hàng.";
                }
                else if (quantity > maxStock)
                {
                    item.Quantity = maxStock;
                    TempData["Warning"] = $"Số lượng tối đa trong kho chỉ còn {maxStock} phần.";
                }
                else
                {
                    item.Quantity = quantity;
                    TempData["Success"] = "Đã cập nhật số lượng món ăn.";
                }
            }

            SaveCart(cart);
            return RedirectToAction("Index");
        }

        // POST: /Cart/Remove
        // Checklist: "Đã remove được sản phẩm ra khỏi giỏ và cập nhật lại số lượng hàng trong giỏ"
        [HttpPost]
        public IActionResult Remove(int productId)
        {
            var cart = GetCart();
            var item = cart.FirstOrDefault(x => x.ProductId == productId);
            if (item != null)
            {
                cart.Remove(item);
                SaveCart(cart);
                TempData["Success"] = $"Đã xóa '{item.ProductName}' khỏi giỏ hàng.";
            }
            return RedirectToAction("Index");
        }

        // GET: /Cart/Checkout (hoặc /datmon.html)
        // Checklist: "Đăng nhập thành công, có truyền thông tin người dùng vào phần Thông tin thanh toán"
        // Checklist: "Đã ẩn nút thanh toán khi giỏ hàng rỗng"
        public async Task<IActionResult> Checkout()
        {
            var cart = GetCart();
            if (!cart.Any())
            {
                TempData["Warning"] = "Giỏ hàng của bạn đang trống! Vui lòng chọn món trước khi thanh toán.";
                return RedirectToAction("Index", "Product");
            }

            var model = new CheckoutViewModel
            {
                CartItems = cart
            };

            // If user is authenticated, pre-fill checkout information!
            if (User.Identity?.IsAuthenticated ?? false)
            {
                var userIdStr = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                if (int.TryParse(userIdStr, out int userId))
                {
                    var user = await _context.Users.FindAsync(userId);
                    if (user != null)
                    {
                        model.CustomerName = user.FullName;
                        model.CustomerPhone = user.Phone ?? string.Empty;
                        model.CustomerAddress = user.Address ?? string.Empty;
                        model.CustomerEmail = user.Email;
                    }
                }
            }

            return View(model);
        }

        // POST: /Cart/Checkout
        // Checklist:
        // - Đơn hàng được tạo ra và lưu vào 2 bảng Order và Order Detail
        // - Đơn hàng có tổng tiền và Thành tiền chi tiết cho từng mục
        // - Đã tính lại số lượng tồn và số lượng đã bán!
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Checkout(CheckoutViewModel model)
        {
            var cart = GetCart();
            if (!cart.Any())
            {
                TempData["Error"] = "Giỏ hàng của bạn đang trống! Không thể thanh toán.";
                return RedirectToAction("Index", "Product");
            }

            model.CartItems = cart;

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Identify user or assign/create customer
            int userId = 0;
            if (User.Identity?.IsAuthenticated ?? false)
            {
                var userIdStr = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                int.TryParse(userIdStr, out userId);
            }

            if (userId == 0)
            {
                // Check if user with this phone or email exists, otherwise find first customer or create
                var existingUser = await _context.Users.FirstOrDefaultAsync(u => u.Email == model.CustomerEmail || u.Phone == model.CustomerPhone);
                if (existingUser != null)
                {
                    userId = existingUser.UserId;
                }
                else
                {
                    // Guest user record
                    var guestUser = new User
                    {
                        Username = "guest_" + DateTime.Now.Ticks,
                        Password = "guestPassword123",
                        FullName = model.CustomerName,
                        Phone = model.CustomerPhone,
                        Address = model.CustomerAddress,
                        Email = string.IsNullOrEmpty(model.CustomerEmail) ? $"guest{DateTime.Now.Ticks}@fastfood.vn" : model.CustomerEmail,
                        Role = "Customer",
                        CreatedAt = DateTime.Now
                    };
                    _context.Users.Add(guestUser);
                    await _context.SaveChangesAsync();
                    userId = guestUser.UserId;
                }
            }

            // Begin transaction for order creation and inventory deduction
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // 1. Create Order
                var order = new Order
                {
                    UserId = userId,
                    OrderDate = DateTime.Now,
                    CustomerName = model.CustomerName,
                    CustomerPhone = model.CustomerPhone,
                    CustomerAddress = model.CustomerAddress,
                    CustomerEmail = model.CustomerEmail,
                    DeliveryType = model.DeliveryType,
                    PaymentMethod = model.PaymentMethod,
                    Notes = model.Notes,
                    TotalAmount = cart.Sum(x => x.SubTotal),
                    Status = "Đang xử lý"
                };

                _context.Orders.Add(order);
                await _context.SaveChangesAsync();

                // 2. Create OrderDetails & Recalculate Stock & Sold Quantity (Checklist nâng cao)
                foreach (var item in cart)
                {
                    var product = await _context.Products.FindAsync(item.ProductId);
                    if (product == null) continue;

                    // Deduct stock quantity and increase sold quantity
                    product.Quantity = Math.Max(0, product.Quantity - item.Quantity);
                    product.SoldQuantity += item.Quantity;

                    var orderDetail = new OrderDetail
                    {
                        OrderId = order.OrderId,
                        ProductId = item.ProductId,
                        Quantity = item.Quantity,
                        UnitPrice = item.Price
                    };
                    _context.OrderDetails.Add(orderDetail);
                }

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                // 3. Clear Cart
                HttpContext.Session.Remove(CartSessionKey);

                TempData["Success"] = $"Đặt món thành công! Đơn hàng #{order.OrderId} đã được tạo và gửi tới nhà bếp.";
                return RedirectToAction("OrderDetail", "Account", new { id = order.OrderId });
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                TempData["Error"] = "Có lỗi xảy ra trong quá trình thanh toán: " + ex.Message;
                return View(model);
            }
        }
    }
}
