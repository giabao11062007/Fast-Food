/* ========================================================
   FASTFOOD STORE - GLOBAL JAVASCRIPT (APP.JS)
   ======================================================== */

// 1. Mobile Navigation Toggle
function toggleNav() {
    const nav = document.getElementById('main-nav');
    if (nav) {
        nav.classList.toggle('open');
    }
}

// 2. Global Toast Notification
function showToast(message, type = 'success') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 99999;
            display: flex;
            flex-direction: column;
            gap: 10px;
            pointer-events: none;
        `;
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    const bgColor = type === 'success' ? '#2A9D8F' : (type === 'error' ? '#E63946' : '#F4A261');
    const icon = type === 'success' ? 'fa-check-circle' : (type === 'error' ? 'fa-times-circle' : 'fa-exclamation-triangle');
    
    toast.style.cssText = `
        background: #fff;
        color: #1D1D1D;
        border-left: 5px solid ${bgColor};
        padding: 14px 20px;
        border-radius: 8px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        display: flex;
        align-items: center;
        gap: 12px;
        font-family: 'Poppins', sans-serif;
        font-size: 0.9rem;
        font-weight: 600;
        min-width: 280px;
        pointer-events: auto;
        transform: translateX(120%);
        transition: transform 0.3s ease-out;
    `;
    toast.innerHTML = `<i class="fa ${icon}" style="color:${bgColor}; font-size:1.2rem;"></i> <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.transform = 'translateX(0)';
    }, 10);

    setTimeout(() => {
        toast.style.transform = 'translateX(120%)';
        setTimeout(() => toast.remove(), 350);
    }, 3500);
}

// 3. Local Cart Management (Client-Side Storage)
const LocalCart = {
    getCart: function() {
        try {
            return JSON.parse(localStorage.getItem('fastfood_cart')) || [
                { id: 1, name: 'Double Beef Burger', price: 59000, img: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&q=80', qty: 1, desc: 'Size Vừa | Không cay' },
                { id: 3, name: 'Gà Rán Giòn Cay', price: 45000, img: 'https://images.unsplash.com/photo-1626645738196-c2a7c87a8f58?w=400&q=80', qty: 2, desc: 'Cay nhẹ' },
                { id: 9, name: 'Coca-Cola Tươi Mát Lạnh', price: 18000, img: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=400&q=80', qty: 1, desc: 'Ly 500ml' }
            ];
        } catch (e) {
            return [];
        }
    },
    saveCart: function(cart) {
        localStorage.setItem('fastfood_cart', JSON.stringify(cart));
        LocalCart.updateBadge();
    },
    addItem: function(product, qty = 1) {
        const cart = LocalCart.getCart();
        const existing = cart.find(x => x.id === product.id);
        if (existing) {
            existing.qty += qty;
        } else {
            cart.push({
                id: product.id,
                name: product.name,
                price: product.price,
                img: product.img,
                qty: qty,
                desc: product.desc || 'Tiêu chuẩn'
            });
        }
        LocalCart.saveCart(cart);
        showToast(`Đã thêm "${product.name}" vào giỏ hàng!`, 'success');
    },
    updateQty: function(id, delta) {
        let cart = LocalCart.getCart();
        const item = cart.find(x => x.id === id);
        if (item) {
            item.qty += delta;
            if (item.qty <= 0) {
                cart = cart.filter(x => x.id !== id);
                showToast(`Đã xóa món khỏi giỏ hàng.`, 'warning');
            }
            LocalCart.saveCart(cart);
        }
        return cart;
    },
    removeItem: function(id) {
        let cart = LocalCart.getCart();
        cart = cart.filter(x => x.id !== id);
        LocalCart.saveCart(cart);
        showToast('Đã xóa món ăn khỏi giỏ hàng.', 'info');
        return cart;
    },
    getTotalQty: function() {
        const cart = LocalCart.getCart();
        return cart.reduce((sum, item) => sum + item.qty, 0);
    },
    getSubTotal: function() {
        const cart = LocalCart.getCart();
        return cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    },
    updateBadge: function() {
        const badges = document.querySelectorAll('.cart-badge');
        const count = LocalCart.getTotalQty();
        badges.forEach(b => {
            b.textContent = count;
            b.style.display = count >= 0 ? 'flex' : 'none';
        });
    }
};

// 4. Auth State Management (Client-Side Storage)
const AuthManager = {
    getUser: function() {
        try {
            return JSON.parse(localStorage.getItem('fastfood_user'));
        } catch (e) {
            return null;
        }
    },
    setUser: function(user) {
        localStorage.setItem('fastfood_user', JSON.stringify(user));
        AuthManager.renderUserHeader();
    },
    logout: function() {
        localStorage.removeItem('fastfood_user');
        showToast('Đã đăng xuất tài khoản thành công.', 'info');
        setTimeout(() => {
            window.location.reload();
        }, 800);
    },
    renderUserHeader: function() {
        const user = AuthManager.getUser();
        const userIconWrap = document.querySelector('.header-icons a[href="#"], .header-icons .user-area');
        if (!userIconWrap) return;

        if (user) {
            // Replace with user profile avatar & dropdown
            userIconWrap.outerHTML = `
                <div class="user-area" style="position:relative; display:inline-block;">
                    <a href="javascript:void(0)" onclick="AuthManager.toggleUserMenu()" style="display:flex; align-items:center; gap:8px; text-decoration:none; color:#ccc; font-size:0.9rem; font-weight:600;">
                        <i class="fa fa-user-circle" style="color:var(--secondary); font-size:1.3rem;"></i>
                        <span class="user-name" style="color:#fff;">${user.fullName || user.username}</span>
                        <i class="fa fa-chevron-down" style="font-size:0.75rem;"></i>
                    </a>
                    <div id="user-dropdown-menu" style="display:none; position:absolute; right:0; top:36px; background:#fff; border-radius:12px; box-shadow:0 10px 30px rgba(0,0,0,0.15); min-width:200px; padding:10px 0; z-index:9999;">
                        <div style="padding:8px 16px; border-bottom:1px solid #f0f0f0; font-size:0.85rem; color:#666;">
                            Xin chào, <strong style="color:var(--dark);">${user.fullName}</strong>
                        </div>
                        <a href="javascript:alert('Hồ sơ khách hàng: ' + (AuthManager.getUser()?.fullName || ''))" style="display:flex; align-items:center; gap:10px; padding:10px 16px; color:#333; text-decoration:none; font-size:0.88rem;">
                            <i class="fa fa-id-card" style="color:var(--primary);"></i> Hồ sơ khách hàng
                        </a>
                        <a href="javascript:alert('Lịch sử đơn hàng: bạn đã đặt 2 đơn hàng thành công!')" style="display:flex; align-items:center; gap:10px; padding:10px 16px; color:#333; text-decoration:none; font-size:0.88rem;">
                            <i class="fa fa-receipt" style="color:#2A9D8F;"></i> Lịch sử giao dịch
                        </a>
                        <hr style="margin:6px 0; border:none; border-top:1px solid #eee;">
                        <a href="javascript:void(0)" onclick="AuthManager.logout()" style="display:flex; align-items:center; gap:10px; padding:10px 16px; color:#e63946; text-decoration:none; font-size:0.88rem; font-weight:600;">
                            <i class="fa fa-sign-out-alt"></i> Đăng xuất
                        </a>
                    </div>
                </div>
            `;
        } else {
            userIconWrap.outerHTML = `
                <a href="dangnhap.html" class="user-login-btn" title="Đăng nhập / Đăng ký" style="color:#ccc; text-decoration:none; font-size:1.15rem;">
                    <i class="fa fa-user-circle"></i>
                </a>
            `;
        }
    },
    toggleUserMenu: function() {
        const menu = document.getElementById('user-dropdown-menu');
        if (menu) {
            menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
        }
    }
};

// Document Click to close user menu
document.addEventListener('click', function(e) {
    const userArea = document.querySelector('.user-area');
    const menu = document.getElementById('user-dropdown-menu');
    if (menu && userArea && !userArea.contains(e.target)) {
        menu.style.display = 'none';
    }
});

// Initialize on DOM Ready
document.addEventListener('DOMContentLoaded', function() {
    LocalCart.updateBadge();
    AuthManager.renderUserHeader();
});
