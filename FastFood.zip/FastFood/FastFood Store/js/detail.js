/* ========================================================
   FASTFOOD STORE - PRODUCT DETAIL JAVASCRIPT (DETAIL.JS)
   ======================================================== */

let baseProductPrice = 59000;
let sizeModifier = 0;
let toppingModifier = 0;
let currentDetailQty = 1;

function updateCalculatedPrice() {
    const singlePrice = baseProductPrice + sizeModifier + toppingModifier;
    const total = singlePrice * currentDetailQty;
    const priceDisplay = document.getElementById('detail-dynamic-price');
    if (priceDisplay) {
        priceDisplay.textContent = `${total.toLocaleString('vi-VN')}đ`;
    }
}

function selectSize(sizeName, extraPrice, element) {
    element.closest('.option-buttons').querySelectorAll('.opt-btn').forEach(b => b.classList.remove('active'));
    element.classList.add('active');
    sizeModifier = extraPrice;
    updateCalculatedPrice();
}

function toggleTopping(toppingName, extraPrice, element) {
    element.classList.toggle('active');
    const isChecked = element.classList.contains('active');
    toppingModifier += isChecked ? extraPrice : -extraPrice;
    if (toppingModifier < 0) toppingModifier = 0;
    updateCalculatedPrice();
}

function changeDetailQty(delta) {
    currentDetailQty = Math.max(1, currentDetailQty + delta);
    const display = document.getElementById('qty-display');
    if (display) display.textContent = currentDetailQty;
    updateCalculatedPrice();
}

function switchDetailImage(thumbElement) {
    document.querySelectorAll('.thumb').forEach(t => t.classList.remove('active'));
    thumbElement.classList.add('active');
    const mainImg = document.getElementById('main-img');
    if (mainImg) {
        mainImg.src = thumbElement.src.replace('w=200', 'w=700');
    }
}

function addDetailToCart() {
    const title = document.getElementById('detail-title')?.textContent || 'Double Beef Burger';
    const mainImg = document.getElementById('main-img')?.src || 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&q=80';
    const activeSize = document.querySelector('.size-options .opt-btn.active')?.textContent.trim() || 'Vừa';
    
    const singlePrice = baseProductPrice + sizeModifier + toppingModifier;

    LocalCart.addItem({
        id: 1,
        name: title,
        price: singlePrice,
        img: mainImg,
        desc: `Size: ${activeSize}`
    }, currentDetailQty);
}

document.addEventListener('DOMContentLoaded', function() {
    // Tabs switcher
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            this.classList.add('active');
            const target = document.getElementById(this.dataset.tab);
            if (target) target.classList.add('active');
        });
    });
});
