/* ========================================================
   FASTFOOD STORE - MENU JAVASCRIPT (MENU.JS)
   ======================================================== */

document.addEventListener('DOMContentLoaded', function() {
    // 1. Category Filter Tabs
    const filterButtons = document.querySelectorAll('.filter-btn');
    const productCards = document.querySelectorAll('.products-grid .card');
    const priceRangeInput = document.getElementById('price-range-slider');
    const priceDisplay = document.getElementById('price-range-val');
    const searchInput = document.getElementById('menu-search-input');
    const sortSelect = document.getElementById('menu-sort-select');

    let activeCategory = 'all';
    let maxPrice = 300000;
    let searchKeyword = '';

    function applyAllFilters() {
        let visibleCount = 0;
        productCards.forEach(card => {
            const cat = card.dataset.cat || 'all';
            const price = parseInt(card.dataset.price) || 0;
            const title = (card.querySelector('.card-title')?.textContent || '').toLowerCase();
            const desc = (card.querySelector('.card-desc')?.textContent || '').toLowerCase();

            const matchCat = (activeCategory === 'all' || cat === activeCategory);
            const matchPrice = (price <= maxPrice);
            const matchSearch = (!searchKeyword || title.includes(searchKeyword) || desc.includes(searchKeyword));

            if (matchCat && matchPrice && matchSearch) {
                card.style.display = '';
                visibleCount++;
            } else {
                card.style.display = 'none';
            }
        });

        const countEl = document.getElementById('menu-count-display');
        if (countEl) countEl.textContent = `Hiển thị ${visibleCount} món ăn`;
    }

    filterButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            filterButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            activeCategory = this.dataset.cat || 'all';
            applyAllFilters();
        });
    });

    // 2. Price Range Slider
    if (priceRangeInput) {
        priceRangeInput.addEventListener('input', function() {
            maxPrice = parseInt(this.value);
            if (priceDisplay) priceDisplay.textContent = `${maxPrice.toLocaleString('vi-VN')}đ`;
            applyAllFilters();
        });
    }

    // 3. Search Filter Input
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            searchKeyword = this.value.trim().toLowerCase();
            applyAllFilters();
        });
    }

    // 4. View Mode Toggle (Grid vs List)
    const gridBtn = document.getElementById('grid-view-btn');
    const listBtn = document.getElementById('list-view-btn');
    const gridContainer = document.getElementById('products-grid');

    if (gridBtn && listBtn && gridContainer) {
        gridBtn.addEventListener('click', function() {
            gridBtn.classList.add('active');
            listBtn.classList.remove('active');
            gridContainer.classList.remove('list-view');
        });

        listBtn.addEventListener('click', function() {
            listBtn.classList.add('active');
            gridBtn.classList.remove('active');
            gridContainer.classList.add('list-view');
        });
    }

    // 5. Add to Cart Buttons
    document.querySelectorAll('.btn-add-cart').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const id = parseInt(this.dataset.id) || Date.now();
            const name = this.dataset.name || 'Món ăn';
            const price = parseInt(this.dataset.price) || 50000;
            const img = this.dataset.img || 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&q=80';

            LocalCart.addItem({ id, name, price, img }, 1);
        });
    });
});
