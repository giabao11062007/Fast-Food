/* ========================================================
   FASTFOOD STORE - AUTHENTICATION JAVASCRIPT (AUTH.JS)
   ======================================================== */

// 1. Switch between Login and Register tabs
function switchAuthTab(tab) {
    const loginTabBtn = document.getElementById('tab-login-btn');
    const registerTabBtn = document.getElementById('tab-register-btn');
    const loginForm = document.getElementById('login-form-box');
    const registerForm = document.getElementById('register-form-box');

    if (tab === 'login') {
        loginTabBtn.classList.add('active');
        registerTabBtn.classList.remove('active');
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
        document.title = "FastFood Store - Đăng Nhập";
    } else {
        registerTabBtn.classList.add('active');
        loginTabBtn.classList.remove('active');
        registerForm.style.display = 'block';
        loginForm.style.display = 'none';
        document.title = "FastFood Store - Đăng Ký";
    }
}

// 2. Toggle password visibility
function togglePassword(inputId, iconBtn) {
    const input = document.getElementById(inputId);
    if (!input) return;
    const isPassword = input.type === 'password';
    input.type = isPassword ? 'text' : 'password';
    const icon = iconBtn.querySelector('i');
    if (icon) {
        icon.className = isPassword ? 'fa fa-eye-slash' : 'fa fa-eye';
    }
}

// 3. Password Strength Checker
function checkPasswordStrength(password) {
    let score = 0;
    if (password.length >= 6) score++;
    if (password.length >= 8) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[^A-Za-z0-9]/.test(password)) score++;

    const bar = document.getElementById('strength-bar');
    const text = document.getElementById('strength-text');
    if (!bar || !text) return;

    if (password.length === 0) {
        bar.style.width = '0%';
        bar.style.backgroundColor = '#ddd';
        text.textContent = '';
        return;
    }

    if (score <= 2) {
        bar.style.width = '33%';
        bar.style.backgroundColor = '#E63946';
        text.textContent = 'Mật khẩu yếu (cần tối thiểu 6 ký tự)';
        text.style.color = '#E63946';
    } else if (score <= 4) {
        bar.style.width = '66%';
        bar.style.backgroundColor = '#F4A261';
        text.textContent = 'Mật khẩu trung bình';
        text.style.color = '#F4A261';
    } else {
        bar.style.width = '100%';
        bar.style.backgroundColor = '#2A9D8F';
        text.textContent = 'Mật khẩu mạnh & an toàn!';
        text.style.color = '#2A9D8F';
    }
}

// 4. Quick Fill Test Account
function fillTestAccount(type) {
    if (type === 'admin') {
        document.getElementById('login-username').value = 'admin';
        document.getElementById('login-password').value = 'admin123';
        showToast('Đã điền thông tin tài khoản Quản trị viên (Admin)', 'info');
    } else {
        document.getElementById('login-username').value = 'customer';
        document.getElementById('login-password').value = 'customer123';
        showToast('Đã điền thông tin tài khoản Khách hàng (Customer)', 'info');
    }
}

// 5. Handle Login Form Submit
function handleLoginSubmit(event) {
    event.preventDefault();
    const usernameInput = document.getElementById('login-username');
    const passwordInput = document.getElementById('login-password');
    const errorBox = document.getElementById('login-error-msg');

    const username = usernameInput.value.trim();
    const password = passwordInput.value;

    errorBox.style.display = 'none';

    // Validation
    if (!username || !password) {
        errorBox.textContent = 'Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu!';
        errorBox.style.display = 'block';
        return;
    }

    // Default registered users list
    let users = [];
    try {
        users = JSON.parse(localStorage.getItem('fastfood_registered_users')) || [];
    } catch(e) { users = []; }

    // Hardcoded test users
    const validUsers = [
        { username: 'admin', password: 'admin123', fullName: 'Quản Trị Viên Hệ Thống', role: 'Admin', email: 'admin@fastfood.vn', phone: '0909123456' },
        { username: 'customer', password: 'customer123', fullName: 'Nguyễn Văn Khách', role: 'Customer', email: 'customer@gmail.com', phone: '0987654321', address: '123 Nguyễn Trãi, Q.1' },
        ...users
    ];

    const matchedUser = validUsers.find(u => u.username.toLowerCase() === username.toLowerCase() && u.password === password);

    if (matchedUser) {
        // Save auth state
        AuthManager.setUser(matchedUser);
        showToast(`Đăng nhập thành công! Chào mừng ${matchedUser.fullName}.`, 'success');

        setTimeout(() => {
            if (matchedUser.role === 'Admin') {
                // If in full ASP.NET project, redirect to /Admin, else index.html
                window.location.href = window.location.pathname.includes('FastFood Store') ? 'index.html' : '/Admin';
            } else {
                window.location.href = 'index.html';
            }
        }, 1000);
    } else {
        errorBox.textContent = 'Đăng nhập thất bại: Tên đăng nhập hoặc mật khẩu không chính xác!';
        errorBox.style.display = 'block';
        showToast('Đăng nhập thất bại. Vui lòng kiểm tra lại!', 'error');
    }
}

// 6. Handle Register Form Submit
function handleRegisterSubmit(event) {
    event.preventDefault();
    const fullname = document.getElementById('reg-fullname').value.trim();
    const username = document.getElementById('reg-username').value.trim();
    const phone = document.getElementById('reg-phone').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const password = document.getElementById('reg-password').value;
    const confirmPassword = document.getElementById('reg-confirm-password').value;
    const address = document.getElementById('reg-address').value.trim();
    const errorBox = document.getElementById('reg-error-msg');

    errorBox.style.display = 'none';

    // Validation checks
    if (!fullname || !username || !phone || !email || !password || !confirmPassword || !address) {
        errorBox.textContent = 'Vui lòng điền đầy đủ tất cả các trường bắt buộc!';
        errorBox.style.display = 'block';
        return;
    }

    if (username.length < 3) {
        errorBox.textContent = 'Tên đăng nhập phải có ít nhất 3 ký tự!';
        errorBox.style.display = 'block';
        return;
    }

    // Phone regex check (Vietnamese 10 digits)
    const phoneRegex = /^(0[3|5|7|8|9])+([0-9]{8})$/;
    if (!phoneRegex.test(phone)) {
        errorBox.textContent = 'Số điện thoại không hợp lệ! Vui lòng nhập 10 chữ số (đầu 03, 05, 07, 08, 09).';
        errorBox.style.display = 'block';
        return;
    }

    // Email regex check
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        errorBox.textContent = 'Định dạng email không hợp lệ (VD: user@example.com)!';
        errorBox.style.display = 'block';
        return;
    }

    if (password.length < 6) {
        errorBox.textContent = 'Mật khẩu phải chứa ít nhất 6 ký tự!';
        errorBox.style.display = 'block';
        return;
    }

    if (password !== confirmPassword) {
        errorBox.textContent = 'Mật khẩu xác nhận không khớp!';
        errorBox.style.display = 'block';
        return;
    }

    // Check duplicate
    let users = [];
    try {
        users = JSON.parse(localStorage.getItem('fastfood_registered_users')) || [];
    } catch(e) { users = []; }

    const isDuplicate = users.some(u => u.username.toLowerCase() === username.toLowerCase() || u.email.toLowerCase() === email.toLowerCase())
                     || ['admin', 'customer'].includes(username.toLowerCase());

    if (isDuplicate) {
        errorBox.textContent = 'Tên đăng nhập hoặc Email này đã tồn tại trong hệ thống!';
        errorBox.style.display = 'block';
        showToast('Tên đăng nhập hoặc Email đã tồn tại!', 'error');
        return;
    }

    // Save new user
    const newUser = {
        username: username,
        password: password,
        fullName: fullname,
        phone: phone,
        email: email,
        address: address,
        role: 'Customer',
        createdAt: new Date().toISOString()
    };
    users.push(newUser);
    localStorage.setItem('fastfood_registered_users', JSON.stringify(users));

    showToast('Đăng ký tài khoản thành công! Bạn có thể đăng nhập ngay.', 'success');

    // Switch to login tab and prefill
    switchAuthTab('login');
    document.getElementById('login-username').value = username;
    document.getElementById('login-password').value = '';
    document.getElementById('login-password').focus();
}
