/* ========================================================
   FASTFOOD STORE - MULTI-STEP CHECKOUT JAVASCRIPT (CHECKOUT.JS)
   ======================================================== */

let currentStep = 1;
let appliedDiscount = 0;
let appliedDiscountCode = '';

// Step Navigation
function goToStep(stepNumber) {
    // Validate current step before advancing
    if (stepNumber > currentStep) {
        if (currentStep === 1 && !validateStep1()) return;
        if (currentStep === 2 && !validateStep2()) return;
        if (currentStep === 3 && !validateStep3()) return;
    }

    currentStep = stepNumber;
    updateStepUI();
    window.scrollTo({ top: 120, behavior: 'smooth' });
}

// Update Step Visuals
function updateStepUI() {
    const steps = document.querySelectorAll('.steps .step');
    const lines = document.querySelectorAll('.steps .step-line');
    
    steps.forEach((step, idx) => {
        const stepNum = idx + 1;
        step.classList.remove('active', 'done');
        if (stepNum < currentStep) {
            step.classList.add('done');
            step.querySelector('.step-icon').innerHTML = '<i class="fa fa-check"></i>';
        } else if (stepNum === currentStep) {
            step.classList.add('active');
            const icons = ['fa-shopping-cart', 'fa-map-marker-alt', 'fa-credit-card', 'fa-check-circle'];
            step.querySelector('.step-icon').innerHTML = `<i class="fa ${icons[idx]}"></i>`;
        } else {
            const icons = ['fa-shopping-cart', 'fa-map-marker-alt', 'fa-credit-card', 'fa-check-circle'];
            step.querySelector('.step-icon').innerHTML = `<i class="fa ${icons[idx]}"></i>`;
        }
    });

    lines.forEach((line, idx) => {
        if (idx + 1 < currentStep) {
            line.classList.add('done');
        } else {
            line.classList.remove('done');
        }
    });

    // Toggle Content Blocks
    for (let i = 1; i <= 4; i++) {
        const block = document.getElementById(`step-content-${i}`);
        if (block) {
            block.style.display = (i === currentStep) ? 'block' : 'none';
        }
    }

    // Refresh review content if reaching Step 4
    if (currentStep === 4) {
        renderOrderReview();
    }
}

// ----------------------------------------------------
// STEP 1 VALIDATION & RENDERING
// ----------------------------------------------------
function renderCheckoutCart() {
    const cart = LocalCart.getCart();
    const container = document.getElementById('checkout-cart-items');
    if (!container) return;

    if (!cart.length) {
        container.innerHTML = `
            <div style="text-align:center; padding:30px; color:#888;">
                <p>Giỏ hàng của bạn đang trống!</p>
                <a href="sanpham.html" class="btn btn-primary" style="margin-top:10px;">Xem Thực Đơn</a>
            </div>
        `;
        return;
    }

    container.innerHTML = cart.map(item => `
        <div class="cart-item" style="padding:12px; margin-bottom:10px; display:flex; align-items:center; gap:14px; background:#fff; border-radius:10px; border:1px solid #eee;">
            <img src="${item.img}" alt="${item.name}" style="width:60px; height:50px; object-fit:cover; border-radius:8px;" />
            <div style="flex:1;">
                <strong style="font-size:0.92rem; color:var(--dark);">${item.name}</strong>
                <div style="font-size:0.8rem; color:var(--gray);">${item.desc || ''}</div>
                <div style="font-size:0.85rem; font-weight:700; color:var(--primary); margin-top:2px;">${item.price.toLocaleString('vi-VN')}đ</div>
            </div>
            <div class="qty-control" style="display:flex; align-items:center; border:1px solid #ddd; border-radius:20px; overflow:hidden;">
                <button type="button" onclick="checkoutChangeQty(${item.id}, -1)" style="border:none; width:26px; height:26px; cursor:pointer; background:#f5f5f5;">-</button>
                <span style="width:30px; text-align:center; font-weight:700; font-size:0.85rem;">${item.qty}</span>
                <button type="button" onclick="checkoutChangeQty(${item.id}, 1)" style="border:none; width:26px; height:26px; cursor:pointer; background:#f5f5f5;">+</button>
            </div>
            <div style="font-weight:800; color:var(--primary); font-size:0.95rem; min-width:80px; text-align:right;">
                ${(item.price * item.qty).toLocaleString('vi-VN')}đ
            </div>
        </div>
    `).join('');

    updatePricingSummary();
}

function checkoutChangeQty(id, delta) {
    LocalCart.updateQty(id, delta);
    renderCheckoutCart();
}

function updatePricingSummary() {
    const subtotal = LocalCart.getSubTotal();
    const isPickup = document.querySelector('.dtype-btn.active')?.dataset.type === 'pickup';
    const shippingFee = (subtotal >= 150000 || isPickup || subtotal === 0) ? 0 : 20000;
    const discountAmount = appliedDiscount > 0 ? (appliedDiscount < 1 ? Math.round(subtotal * appliedDiscount) : appliedDiscount) : 0;
    const grandTotal = Math.max(0, subtotal + shippingFee - discountAmount);

    document.querySelectorAll('.val-subtotal').forEach(el => el.textContent = `${subtotal.toLocaleString('vi-VN')}đ`);
    document.querySelectorAll('.val-shipping').forEach(el => {
        el.textContent = shippingFee === 0 ? 'Miễn phí' : `${shippingFee.toLocaleString('vi-VN')}đ`;
        el.style.color = shippingFee === 0 ? '#2A9D8F' : 'var(--dark)';
    });
    document.querySelectorAll('.val-discount').forEach(el => {
        el.textContent = discountAmount > 0 ? `-${discountAmount.toLocaleString('vi-VN')}đ` : '0đ';
    });
    document.querySelectorAll('.val-grandtotal').forEach(el => el.textContent = `${grandTotal.toLocaleString('vi-VN')}đ`);
    
    const placeBtn = document.getElementById('btn-submit-order');
    if (placeBtn) {
        placeBtn.innerHTML = `<i class="fa fa-check-circle me-1"></i> XÁC NHẬN ĐẶT MÓN — ${grandTotal.toLocaleString('vi-VN')}đ`;
    }

    // Update QR Code Amount
    updateVietQR(grandTotal);
}

function applyCheckoutCoupon() {
    const input = document.getElementById('checkout-coupon-input');
    if (!input) return;
    const code = input.value.trim().toUpperCase();

    if (code === 'FASTFOOD10') {
        appliedDiscount = 0.10; // 10%
        appliedDiscountCode = code;
        showToast('Áp dụng mã FASTFOOD10 giảm 10% thành công!', 'success');
    } else if (code === 'FREESHIP') {
        appliedDiscount = 20000;
        appliedDiscountCode = code;
        showToast('Áp dụng mã FREESHIP miễn phí giao hàng!', 'success');
    } else if (code === 'NEWUSER20') {
        appliedDiscount = 0.20; // 20%
        appliedDiscountCode = code;
        showToast('Áp dụng mã thành viên mới NEWUSER20 giảm 20%!', 'success');
    } else {
        appliedDiscount = 0;
        appliedDiscountCode = '';
        showToast('Mã giảm giá không hợp lệ hoặc đã hết hạn!', 'error');
    }
    updatePricingSummary();
}

function validateStep1() {
    const cart = LocalCart.getCart();
    if (!cart.length) {
        showToast('Giỏ hàng trống! Vui lòng chọn món trước khi đặt hàng.', 'error');
        return false;
    }
    return true;
}

// ----------------------------------------------------
// STEP 2 VALIDATION & LOGIC
// ----------------------------------------------------
function validateStep2() {
    const name = document.getElementById('cust-name')?.value.trim();
    const phone = document.getElementById('cust-phone')?.value.trim();
    const isPickup = document.querySelector('.dtype-btn.active')?.dataset.type === 'pickup';

    if (!name) {
        showToast('Vui lòng nhập họ và tên người nhận!', 'error');
        document.getElementById('cust-name')?.focus();
        return false;
    }

    const phoneRegex = /^(0[3|5|7|8|9])+([0-9]{8})$/;
    if (!phone || !phoneRegex.test(phone)) {
        showToast('Vui lòng nhập số điện thoại hợp lệ (10 chữ số)!', 'error');
        document.getElementById('cust-phone')?.focus();
        return false;
    }

    if (!isPickup) {
        const address = document.getElementById('cust-address')?.value.trim();
        const city = document.getElementById('cust-city')?.value;
        const district = document.getElementById('cust-district')?.value;

        if (!city) {
            showToast('Vui lòng chọn Tỉnh / Thành phố giao hàng!', 'error');
            return false;
        }
        if (!district) {
            showToast('Vui lòng chọn Quận / Huyện giao hàng!', 'error');
            return false;
        }
        if (!address) {
            showToast('Vui lòng nhập số nhà, tên đường chi tiết!', 'error');
            document.getElementById('cust-address')?.focus();
            return false;
        }
    }
    return true;
}

// ----------------------------------------------------
// STEP 3 PAYMENT LOGIC & VIETQR DYNAMIC
// ----------------------------------------------------
function selectPaymentMethod(method, element) {
    document.querySelectorAll('.payment-option-card').forEach(el => el.classList.remove('selected'));
    if (element) element.classList.add('selected');
    
    const radio = document.querySelector(`input[name="paymentMethod"][value="${method}"]`);
    if (radio) radio.checked = true;

    // Show / hide specific payment details
    const qrBox = document.getElementById('vietqr-box');
    const momoBox = document.getElementById('momo-box');
    const cardBox = document.getElementById('card-input-box');

    if (qrBox) qrBox.style.display = (method === 'banking') ? 'block' : 'none';
    if (momoBox) momoBox.style.display = (method === 'momo') ? 'block' : 'none';
    if (cardBox) cardBox.style.display = (method === 'card') ? 'block' : 'none';
}

function updateVietQR(amount) {
    const qrImg = document.getElementById('vietqr-image');
    if (qrImg) {
        const memo = encodeURIComponent(`FASTFOOD_${Math.floor(100000 + Math.random() * 900000)}`);
        qrImg.src = `https://img.vietqr.io/image/MB-0909123456-compact2.png?amount=${amount}&addInfo=${memo}&accountName=FASTFOOD%20STORE`;
    }
}

function validateStep3() {
    const method = document.querySelector('input[name="paymentMethod"]:checked')?.value;
    if (!method) {
        showToast('Vui lòng chọn một phương thức thanh toán!', 'error');
        return false;
    }
    return true;
}

// ----------------------------------------------------
// STEP 4 ORDER REVIEW & PLACEMENT
// ----------------------------------------------------
function renderOrderReview() {
    const name = document.getElementById('cust-name')?.value.trim();
    const phone = document.getElementById('cust-phone')?.value.trim();
    const email = document.getElementById('cust-email')?.value.trim();
    const isPickup = document.querySelector('.dtype-btn.active')?.dataset.type === 'pickup';
    
    let deliveryStr = '';
    if (isPickup) {
        const store = document.querySelector('input[name="store"]:checked')?.closest('.store-option')?.querySelector('strong')?.textContent || 'FastFood Quận 1';
        deliveryStr = `Đến lấy tại cửa hàng: <strong>${store}</strong>`;
    } else {
        const address = document.getElementById('cust-address')?.value.trim();
        const district = document.getElementById('cust-district')?.value || '';
        const city = document.getElementById('cust-city')?.value || '';
        deliveryStr = `Giao tận nơi: <strong>${address}, ${district}, ${city}</strong>`;
    }

    const isSchedule = document.querySelector('input[name="time"]:checked')?.value === 'schedule';
    let timeStr = isSchedule ? 'Đặt lịch giao hàng' : 'Giao ngay (25-35 phút)';

    const payMethod = document.querySelector('input[name="paymentMethod"]:checked')?.value || 'cod';
    const payNames = {
        'cod': 'Tiền mặt khi nhận hàng (COD)',
        'banking': 'Chuyển khoản Ngân hàng (VietQR)',
        'momo': 'Ví điện tử MoMo',
        'card': 'Thẻ tín dụng / Ghi nợ quốc tế'
    };

    const reviewBox = document.getElementById('review-info-box');
    if (reviewBox) {
        reviewBox.innerHTML = `
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px; font-size:0.88rem; background:#f9f9f9; padding:18px; border-radius:12px; margin-bottom:16px;">
                <div><strong>Người nhận:</strong> ${name}</div>
                <div><strong>Số điện thoại:</strong> ${phone}</div>
                <div style="grid-column:1/-1;"><strong>Hình thức giao nhận:</strong> ${deliveryStr}</div>
                <div><strong>Thời gian nhận:</strong> ${timeStr}</div>
                <div><strong>Phương thức thanh toán:</strong> <span style="color:var(--primary); font-weight:700;">${payNames[payMethod] || payMethod}</span></div>
                ${email ? `<div style="grid-column:1/-1;"><strong>Email:</strong> ${email}</div>` : ''}
            </div>
        `;
    }
}

// ----------------------------------------------------
// COMPLETE ORDER (SHOW SUCCESS MODAL & INVOICE)
// ----------------------------------------------------
function confirmOrderSuccess() {
    const orderId = 'FF' + Math.floor(100000 + Math.random() * 900000);
    const subtotal = LocalCart.getSubTotal();
    const isPickup = document.querySelector('.dtype-btn.active')?.dataset.type === 'pickup';
    const shippingFee = (subtotal >= 150000 || isPickup) ? 0 : 20000;
    const discountAmount = appliedDiscount > 0 ? (appliedDiscount < 1 ? Math.round(subtotal * appliedDiscount) : appliedDiscount) : 0;
    const grandTotal = Math.max(0, subtotal + shippingFee - discountAmount);

    document.getElementById('modal-order-id').textContent = '#' + orderId;
    document.getElementById('modal-order-total').textContent = `${grandTotal.toLocaleString('vi-VN')}đ`;

    // Show Success Modal
    const modal = document.getElementById('success-modal');
    if (modal) modal.style.display = 'flex';

    // Clear Cart
    LocalCart.saveCart([]);

    showToast(`Đặt món thành công! Mã đơn #${orderId}`, 'success');
}

// Auto-fill user info if logged in
document.addEventListener('DOMContentLoaded', function() {
    renderCheckoutCart();

    // Prefill from AuthManager
    const user = AuthManager.getUser();
    if (user) {
        if (document.getElementById('cust-name') && user.fullName) document.getElementById('cust-name').value = user.fullName;
        if (document.getElementById('cust-phone') && user.phone) document.getElementById('cust-phone').value = user.phone;
        if (document.getElementById('cust-email') && user.email) document.getElementById('cust-email').value = user.email;
        if (document.getElementById('cust-address') && user.address) document.getElementById('cust-address').value = user.address;
    }

    // Tab delivery type listeners
    document.querySelectorAll('.dtype-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.dtype-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            const isDelivery = this.dataset.type === 'delivery';
            const delForm = document.getElementById('delivery-form');
            const picForm = document.getElementById('pickup-form');
            if (delForm) delForm.style.display = isDelivery ? 'block' : 'none';
            if (picForm) picForm.style.display = isDelivery ? 'none' : 'block';
            updatePricingSummary();
        });
    });

    // Time schedule radio listeners
    document.querySelectorAll('input[name="time"]').forEach(r => {
        r.addEventListener('change', function() {
            const picker = document.getElementById('schedule-picker');
            if (picker) picker.style.display = this.value === 'schedule' ? 'block' : 'none';
        });
    });
});
