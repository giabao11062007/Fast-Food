/* ========================================================
   FASTFOOD STORE - CART JAVASCRIPT (CART.JS)
   ======================================================== */

let cartCouponDiscount = 0;
let cartCouponCode = '';

function renderCartPage() {
    const cart = LocalCart.getCart();
    const container = document.getElementById('cart-items-container');
    const emptyBox = document.getElementById('cart-empty-state');
    const checkoutBtn = document.getElementById('btn-cart-checkout');
    const summaryCol = document.getElementById('cart-summary-col');

    if (!container) return;

    if (!cart.length) {
        if (container) container.innerHTML = '';
        if (emptyBox) emptyBox.style.display = 'block';
        if (checkoutBtn) checkoutBtn.style.display = 'none'; // ẨN NÚT THANH TOÁN KHI GIỎ RỖNG
        if (summaryCol) summaryCol.style.opacity = '0.5';
        LocalCart.updateBadge();
        return;
    }

    if (emptyBox) emptyBox.style.display = 'none';
    if (checkoutBtn) checkoutBtn.style.display = 'block';
    if (summaryCol) summaryCol.style.opacity = '1';

    container.innerHTML = cart.map(item => `
        <div class="cart-item" id="cart-row-${item.id}" style="display:flex; align-items:center; gap:16px; padding:18px; border-radius:12px; margin-bottom:14px; background:#fff; box-shadow:0 2px 10px rgba(0,0,0,0.06); position:relative; transition:all 0.3s ease;">
            <img src="${item.img}" alt="${item.name}" class="cart-item-img" style="width:90px; height:80px; object-fit:cover; border-radius:10px; flex-shrink:0;" />
            <div class="cart-item-info" style="flex:1;">
                <h3 style="font-size:1rem; font-weight:700; color:var(--dark); margin-bottom:3px;">${item.name}</h3>
                <div class="item-options" style="font-size:0.8rem; color:var(--gray); margin-bottom:10px;">${item.desc || 'Tiêu chuẩn'}</div>
                <div class="item-price-row" style="display:flex; align-items:center; gap:16px; flex-wrap:wrap;">
                    <span class="item-price" style="font-size:0.9rem; color:var(--gray);">${item.price.toLocaleString('vi-VN')}đ</span>
                    <div class="qty-control" style="display:flex; align-items:center; border-radius:20px; overflow:hidden; border:2px solid var(--primary);">
                        <button type="button" onclick="handleCartQty(${item.id}, -1)" style="width:30px; height:30px; border:none; font-size:1.1rem; font-weight:700; cursor:pointer; background:#fff3f3; color:var(--primary);">-</button>
                        <span class="qty-val" style="width:36px; text-align:center; font-weight:700;">${item.qty}</span>
                        <button type="button" onclick="handleCartQty(${item.id}, 1)" style="width:30px; height:30px; border:none; font-size:1.1rem; font-weight:700; cursor:pointer; background:#fff3f3; color:var(--primary);">+</button>
                    </div>
                    <span class="item-subtotal" style="font-size:1rem; font-weight:800; color:var(--primary); margin-left:auto;">
                        ${(item.price * item.qty).toLocaleString('vi-VN')}đ
                    </span>
                </div>
            </div>
            <button class="item-remove" onclick="handleCartRemove(${item.id})" style="position:absolute; top:12px; right:12px; background:none; border:none; cursor:pointer; font-size:1.1rem; color:#ccc;" title="Xóa món ăn">
                <i class="fa fa-times"></i>
            </button>
        </div>
    `).join('');

    updateCartTotals();
    LocalCart.updateBadge();
}

function handleCartQty(id, delta) {
    LocalCart.updateQty(id, delta);
    renderCartPage();
}

function handleCartRemove(id) {
    const row = document.getElementById(`cart-row-${id}`);
    if (row) {
        row.style.opacity = '0';
        row.style.transform = 'scale(0.95)';
        setTimeout(() => {
            LocalCart.removeItem(id);
            renderCartPage();
        }, 300);
    }
}

function handleClearAllCart() {
    if (confirm('Bạn có chắc chắn muốn xóa toàn bộ món ăn trong giỏ hàng?')) {
        LocalCart.saveCart([]);
        renderCartPage();
        showToast('Đã xóa toàn bộ giỏ hàng.', 'info');
    }
}

function updateCartTotals() {
    const subtotal = LocalCart.getSubTotal();
    const shippingFee = (subtotal >= 150000 || subtotal === 0) ? 0 : 20000;
    const discount = cartCouponDiscount > 0 ? (cartCouponDiscount < 1 ? Math.round(subtotal * cartCouponDiscount) : cartCouponDiscount) : 0;
    const total = Math.max(0, subtotal + shippingFee - discount);

    document.querySelectorAll('.cart-val-subtotal').forEach(el => el.textContent = `${subtotal.toLocaleString('vi-VN')}đ`);
    document.querySelectorAll('.cart-val-shipping').forEach(el => {
        el.textContent = shippingFee === 0 ? 'Miễn phí' : `${shippingFee.toLocaleString('vi-VN')}đ`;
        el.className = shippingFee === 0 ? 'free' : '';
    });
    document.querySelectorAll('.cart-val-discount').forEach(el => {
        el.textContent = discount > 0 ? `-${discount.toLocaleString('vi-VN')}đ` : '0đ';
    });
    document.querySelectorAll('.cart-val-total').forEach(el => el.textContent = `${total.toLocaleString('vi-VN')}đ`);
}

function applyCouponCode() {
    const input = document.getElementById('coupon-input');
    if (!input) return;
    const code = input.value.trim().toUpperCase();

    if (code === 'FASTFOOD10') {
        cartCouponDiscount = 0.10;
        cartCouponCode = code;
        showToast(`Áp dụng mã "${code}" giảm 10% thành công!`, 'success');
    } else if (code === 'FREESHIP') {
        cartCouponDiscount = 20000;
        cartCouponCode = code;
        showToast(`Áp dụng mã "${code}" miễn phí vận chuyển!`, 'success');
    } else if (code === 'NEWUSER20') {
        cartCouponDiscount = 0.20;
        cartCouponCode = code;
        showToast(`Áp dụng mã "${code}" giảm 20% cho thành viên mới!`, 'success');
    } else {
        cartCouponDiscount = 0;
        cartCouponCode = '';
        showToast('Mã giảm giá không hợp lệ hoặc đã hết lượt dùng!', 'error');
    }

    updateCartTotals();
}

function quickUseCoupon(code) {
    const input = document.getElementById('coupon-input');
    if (input) {
        input.value = code;
        applyCouponCode();
    }
}

document.addEventListener('DOMContentLoaded', function() {
    renderCartPage();
});
