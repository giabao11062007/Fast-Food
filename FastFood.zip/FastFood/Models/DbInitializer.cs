using Microsoft.EntityFrameworkCore;

namespace FastFood.Models
{
    public static class DbInitializer
    {
        public static void Initialize(FastFoodContext context)
        {
            context.Database.EnsureCreated();

            // Check if DB already seeded
            if (context.Categories.Any())
            {
                return; // DB has been seeded
            }

            // 1. Seed Categories
            var categories = new Category[]
            {
                new Category { CategoryName = "Burger", Description = "Bánh kẹp burger thơm ngon hảo hạng với bò Mỹ và phô mai", Icon = "🍔" },
                new Category { CategoryName = "Khoai Tây", Description = "Khoai tây chiên vàng giòn rụm với bơ và phô mai lắc", Icon = "🍟" },
                new Category { CategoryName = "Gà Rán", Description = "Gà tươi ướp đậm đà giòn cay chuẩn vị", Icon = "🍗" },
                new Category { CategoryName = "Pizza", Description = "Pizza nướng lò thơm lừng phô mai kéo sợi", Icon = "🍕" },
                new Category { CategoryName = "Đồ Uống", Description = "Nước giải khát mát lạnh sảng khoái", Icon = "🥤" },
                new Category { CategoryName = "Combo", Description = "Combo tiết kiệm đầy đủ món ăn và nước uống", Icon = "🎁" },
                new Category { CategoryName = "Tacos", Description = "Bánh kẹp kiểu Mexico giòn rụm nhân bò xé", Icon = "🌮" }
            };

            context.Categories.AddRange(categories);
            context.SaveChanges();

            // 2. Seed Users
            var users = new User[]
            {
                new User
                {
                    Username = "admin",
                    Password = "admin123", // In actual app or practice we can keep simple password or hash
                    FullName = "Quản Trị Viên Hệ Thống",
                    Email = "admin@fastfood.vn",
                    Phone = "0909123456",
                    Address = "Văn phòng FastFood Store, Q.1, TP.HCM",
                    Role = "Admin",
                    CreatedAt = DateTime.Now.AddDays(-30)
                },
                new User
                {
                    Username = "customer",
                    Password = "customer123",
                    FullName = "Nguyễn Văn Khách",
                    Email = "customer@gmail.com",
                    Phone = "0987654321",
                    Address = "123 Đường Nguyễn Trãi, Phường Bến Thành, Quận 1, TP. Hồ Chí Minh",
                    Role = "Customer",
                    CreatedAt = DateTime.Now.AddDays(-20)
                },
                new User
                {
                    Username = "lethimy",
                    Password = "customer123",
                    FullName = "Lê Thị Mỹ",
                    Email = "lethimy@gmail.com",
                    Phone = "0912345678",
                    Address = "456 Đường Lê Lợi, Quận 1, TP. Hồ Chí Minh",
                    Role = "Customer",
                    CreatedAt = DateTime.Now.AddDays(-15)
                }
            };

            context.Users.AddRange(users);
            context.SaveChanges();

            // 3. Seed Products
            var catBurger = categories[0].CategoryId;
            var catFries = categories[1].CategoryId;
            var catChicken = categories[2].CategoryId;
            var catPizza = categories[3].CategoryId;
            var catDrink = categories[4].CategoryId;
            var catCombo = categories[5].CategoryId;
            var catTacos = categories[6].CategoryId;

            var products = new Product[]
            {
                new Product
                {
                    ProductName = "Double Beef Burger",
                    CategoryId = catBurger,
                    Price = 59000,
                    OldPrice = 75000,
                    Quantity = 45,
                    SoldQuantity = 128,
                    ImageUrl = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&q=80",
                    Description = "Hai lớp thịt bò Úc tươi thượng hạng nướng lửa hồng, kèm phô mai Cheddar chảy quyện, xà lách giòn và sốt đặc biệt bí truyền.",
                    Rating = 5.0,
                    IsFeatured = true,
                    IsCombo = false
                },
                new Product
                {
                    ProductName = "Burger Gà Giòn Phô Mai",
                    CategoryId = catBurger,
                    Price = 49000,
                    OldPrice = 60000,
                    Quantity = 30,
                    SoldQuantity = 85,
                    ImageUrl = "https://images.unsplash.com/photo-1550547660-d9450f859349?w=600&q=80",
                    Description = "Miếng ức gà chiên giòn rụm kết hợp sốt mayonnaise cay nhẹ và phô mai béo ngậy.",
                    Rating = 4.8,
                    IsFeatured = true,
                    IsCombo = false
                },
                new Product
                {
                    ProductName = "Gà Rán Giòn Cay",
                    CategoryId = catChicken,
                    Price = 45000,
                    OldPrice = 55000,
                    Quantity = 50,
                    SoldQuantity = 98,
                    ImageUrl = "https://images.unsplash.com/photo-1626645738196-c2a7c87a8f58?w=600&q=80",
                    Description = "Gà tươi ướp gia vị 12 loại thảo mộc, lớp vỏ chiên xù vàng óng giòn tan, thịt bên trong mềm ngọt mọng nước.",
                    Rating = 4.9,
                    IsFeatured = true,
                    IsCombo = false
                },
                new Product
                {
                    ProductName = "Cánh Gà Sốt Chua Ngọt",
                    CategoryId = catChicken,
                    Price = 52000,
                    OldPrice = 65000,
                    Quantity = 25,
                    SoldQuantity = 64,
                    ImageUrl = "https://images.unsplash.com/photo-1567620832903-9fc6debc209f?w=600&q=80",
                    Description = "Cánh gà chiên giòn đảo sốt chua ngọt đậm vị kiểu Hàn Quốc, rắc mè trắng rang thơm.",
                    Rating = 4.7,
                    IsFeatured = false,
                    IsCombo = false
                },
                new Product
                {
                    ProductName = "Pizza 4 Phô Mai (Quattro)",
                    CategoryId = catPizza,
                    Price = 89000,
                    OldPrice = 110000,
                    Quantity = 20,
                    SoldQuantity = 201,
                    ImageUrl = "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=600&q=80",
                    Description = "Đế pizza nướng củi giòn ngoài mềm trong, hòa quyện 4 loại phô mai hảo hạng: Mozzarella, Gorgonzola, Fontina và Parmesan.",
                    Rating = 5.0,
                    IsFeatured = true,
                    IsCombo = false
                },
                new Product
                {
                    ProductName = "Pizza Hải Sản Nhiệt Đới",
                    CategoryId = catPizza,
                    Price = 99000,
                    OldPrice = 120000,
                    Quantity = 15,
                    SoldQuantity = 115,
                    ImageUrl = "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600&q=80",
                    Description = "Tôm, mực, thanh cua tươi phủ sốt cà chua cay dịu và phô mai Mozzarella béo ngậy kèm dứa thơm lừng.",
                    Rating = 4.8,
                    IsFeatured = false,
                    IsCombo = false
                },
                new Product
                {
                    ProductName = "Khoai Tây Chiên Bơ Tỏi",
                    CategoryId = catFries,
                    Price = 29000,
                    OldPrice = 35000,
                    Quantity = 60,
                    SoldQuantity = 76,
                    ImageUrl = "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=600&q=80",
                    Description = "Khoai tây cắt lát giòn rụm vàng ươm, lắc đều cùng bơ thực vật thơm lừng và sốt tỏi ớt hấp dẫn.",
                    Rating = 4.6,
                    IsFeatured = true,
                    IsCombo = false
                },
                new Product
                {
                    ProductName = "Khoai Tây Lắc Phô Mai",
                    CategoryId = catFries,
                    Price = 32000,
                    OldPrice = 40000,
                    Quantity = 40,
                    SoldQuantity = 92,
                    ImageUrl = "https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?w=600&q=80",
                    Description = "Khoai tây chiên giòn rụm phủ lớp bột phô mai mặn ngọt đậm đà khó cưỡng.",
                    Rating = 4.7,
                    IsFeatured = false,
                    IsCombo = false
                },
                new Product
                {
                    ProductName = "Coca-Cola Tươi Mát Lạnh",
                    CategoryId = catDrink,
                    Price = 18000,
                    OldPrice = 20000,
                    Quantity = 100,
                    SoldQuantity = 320,
                    ImageUrl = "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=600&q=80",
                    Description = "Ly nước ngọt có gas mát lạnh sảng khoái với đá bi và lát chanh tươi.",
                    Rating = 4.9,
                    IsFeatured = false,
                    IsCombo = false
                },
                new Product
                {
                    ProductName = "Trà Đào Cam Sả",
                    CategoryId = catDrink,
                    Price = 28000,
                    OldPrice = 35000,
                    Quantity = 35,
                    SoldQuantity = 88,
                    ImageUrl = "https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=600&q=80",
                    Description = "Hương vị trà đen đậm đà hòa quyện cùng tinh dầu sả, nước cốt cam tươi và những miếng đào giòn ngọt.",
                    Rating = 4.8,
                    IsFeatured = false,
                    IsCombo = false
                },
                new Product
                {
                    ProductName = "Combo Burger Đôi",
                    CategoryId = catCombo,
                    Price = 120000,
                    OldPrice = 150000,
                    Quantity = 20,
                    SoldQuantity = 140,
                    ImageUrl = "https://images.unsplash.com/photo-1551782450-a2132b4ba21d?w=600&q=80",
                    Description = "Bao gồm 2 Burger Bò Thượng Hạng + 2 Phần Khoai Tây Chiên Vàng + 2 Ly Coca-Cola Mát Lạnh (Tiết kiệm 20%).",
                    Rating = 5.0,
                    IsFeatured = false,
                    IsCombo = true
                },
                new Product
                {
                    ProductName = "Combo Gia Đình Sung Túc",
                    CategoryId = catCombo,
                    Price = 225000,
                    OldPrice = 300000,
                    Quantity = 12,
                    SoldQuantity = 60,
                    ImageUrl = "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600&q=80",
                    Description = "Bao gồm 1 Pizza lớn 4 Phô Mai + 4 Miếng Gà Rán Giòn Cay + 4 Ly Nước Ngọt (Tiết kiệm 25%).",
                    Rating = 5.0,
                    IsFeatured = false,
                    IsCombo = true
                },
                new Product
                {
                    ProductName = "Combo Một Mình Thảnh Thơi",
                    CategoryId = catCombo,
                    Price = 68000,
                    OldPrice = 80000,
                    Quantity = 28,
                    SoldQuantity = 110,
                    ImageUrl = "https://images.unsplash.com/photo-1585032226651-759b368d7246?w=600&q=80",
                    Description = "Bao gồm 1 Burger Bò / Gà tùy chọn + 1 Khoai Tây Nhỏ + 1 Ly Nước Ngọt (Tiết kiệm 15%).",
                    Rating = 4.8,
                    IsFeatured = false,
                    IsCombo = true
                },
                new Product
                {
                    ProductName = "Tacos Bò Nướng Mexico",
                    CategoryId = catTacos,
                    Price = 48000,
                    OldPrice = 58000,
                    Quantity = 18,
                    SoldQuantity = 45,
                    ImageUrl = "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=600&q=80",
                    Description = "Vỏ bánh bắp giòn rụm cuộn thịt bò xé ướp sốt salsa cà chua và phô mai kem béo ngậy.",
                    Rating = 4.7,
                    IsFeatured = false,
                    IsCombo = false
                },
                // Add an out-of-stock product to demonstrate the checklist rule:
                // "Quản lý kho hàng: Thống kê hàng theo 2 phần: Danh sách hàng tồn (qty > 0), Danh sách hàng cần nhập (qty = 0)"
                new Product
                {
                    ProductName = "Burger Cá Tuyết Phô Mai",
                    CategoryId = catBurger,
                    Price = 62000,
                    OldPrice = 75000,
                    Quantity = 0, // Out of stock!
                    SoldQuantity = 95,
                    ImageUrl = "https://images.unsplash.com/photo-1520072959219-c595dc870360?w=600&q=80",
                    Description = "Phi lê cá tuyết Alaska lăn bột chiên xù, ăn kèm sốt Tartar và phô mai lá cao cấp (Tạm hết hàng).",
                    Rating = 4.6,
                    IsFeatured = false,
                    IsCombo = false
                },
                new Product
                {
                    ProductName = "Gà Popcorn Lắc Rong Biển",
                    CategoryId = catChicken,
                    Price = 38000,
                    OldPrice = 45000,
                    Quantity = 0, // Out of stock!
                    SoldQuantity = 52,
                    ImageUrl = "https://images.unsplash.com/photo-1562967914-608f82629710?w=600&q=80",
                    Description = "Viên gà không xương chiên giòn cắn ngập miệng lắc bột rong biển thơm ngon (Tạm hết hàng).",
                    Rating = 4.5,
                    IsFeatured = false,
                    IsCombo = false
                }
            };

            context.Products.AddRange(products);
            context.SaveChanges();

            // 4. Seed Sample Orders and OrderDetails for Customer
            var customerUser = users[1]; // customer
            var order1 = new Order
            {
                UserId = customerUser.UserId,
                OrderDate = DateTime.Now.AddDays(-2),
                CustomerName = customerUser.FullName,
                CustomerPhone = customerUser.Phone ?? "0987654321",
                CustomerAddress = customerUser.Address ?? "123 Đường Nguyễn Trãi, Q.1",
                CustomerEmail = customerUser.Email,
                DeliveryType = "Giao tận nơi (30 phút)",
                PaymentMethod = "Tiền mặt khi nhận hàng (COD)",
                Notes = "Giao lúc 12h trưa giúp mình nhé",
                TotalAmount = 149000,
                Status = "Đã giao hàng"
            };

            context.Orders.Add(order1);
            context.SaveChanges();

            var orderDetails1 = new OrderDetail[]
            {
                new OrderDetail
                {
                    OrderId = order1.OrderId,
                    ProductId = products[0].ProductId, // Double Beef Burger
                    Quantity = 1,
                    UnitPrice = 59000
                },
                new OrderDetail
                {
                    OrderId = order1.OrderId,
                    ProductId = products[4].ProductId, // Pizza 4 Phô Mai
                    Quantity = 1,
                    UnitPrice = 89000
                }
            };
            context.OrderDetails.AddRange(orderDetails1);
            context.SaveChanges();

            var order2 = new Order
            {
                UserId = customerUser.UserId,
                OrderDate = DateTime.Now.AddHours(-5),
                CustomerName = customerUser.FullName,
                CustomerPhone = customerUser.Phone ?? "0987654321",
                CustomerAddress = customerUser.Address ?? "123 Đường Nguyễn Trãi, Q.1",
                CustomerEmail = customerUser.Email,
                DeliveryType = "Giao tận nơi (30 phút)",
                PaymentMethod = "Chuyển khoản ngân hàng",
                Notes = "Ít đá, tương cà nhiều hơn tương ớt",
                TotalAmount = 120000,
                Status = "Đang xử lý"
            };
            context.Orders.Add(order2);
            context.SaveChanges();

            var orderDetails2 = new OrderDetail[]
            {
                new OrderDetail
                {
                    OrderId = order2.OrderId,
                    ProductId = products[10].ProductId, // Combo Burger Đôi
                    Quantity = 1,
                    UnitPrice = 120000
                }
            };
            context.OrderDetails.AddRange(orderDetails2);
            context.SaveChanges();
        }
    }
}
