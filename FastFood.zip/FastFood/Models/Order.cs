using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FastFood.Models
{
    [Table("Orders")]
    public class Order
    {
        [Key]
        [Display(Name = "Mã đơn hàng")]
        public int OrderId { get; set; }

        [Required]
        [Display(Name = "Khách hàng")]
        public int UserId { get; set; }

        [Display(Name = "Ngày đặt hàng")]
        public DateTime OrderDate { get; set; } = DateTime.Now;

        [Required(ErrorMessage = "Tên người nhận không được để trống")]
        [StringLength(100, ErrorMessage = "Tên người nhận không quá 100 ký tự")]
        [Display(Name = "Người nhận")]
        public string CustomerName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Số điện thoại nhận hàng không được để trống")]
        [StringLength(20, ErrorMessage = "Số điện thoại không quá 20 ký tự")]
        [Phone(ErrorMessage = "Số điện thoại không hợp lệ")]
        [Display(Name = "Số điện thoại")]
        public string CustomerPhone { get; set; } = string.Empty;

        [Required(ErrorMessage = "Địa chỉ nhận hàng không được để trống")]
        [StringLength(255, ErrorMessage = "Địa chỉ không quá 255 ký tự")]
        [Display(Name = "Địa chỉ giao hàng")]
        public string CustomerAddress { get; set; } = string.Empty;

        [EmailAddress(ErrorMessage = "Email không hợp lệ")]
        [StringLength(100)]
        [Display(Name = "Email")]
        public string? CustomerEmail { get; set; }

        [StringLength(50)]
        [Display(Name = "Hình thức nhận hàng")]
        public string DeliveryType { get; set; } = "Giao tận nơi";

        [StringLength(50)]
        [Display(Name = "Phương thức thanh toán")]
        public string PaymentMethod { get; set; } = "Tiền mặt (COD)";

        [StringLength(500)]
        [Display(Name = "Ghi chú")]
        public string? Notes { get; set; }

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Tổng tiền")]
        public decimal TotalAmount { get; set; }

        [StringLength(50)]
        [Display(Name = "Trạng thái đơn hàng")]
        public string Status { get; set; } = "Đang xử lý";

        [ForeignKey("UserId")]
        [Display(Name = "Tài khoản")]
        public virtual User? User { get; set; }

        public virtual ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();
    }
}
