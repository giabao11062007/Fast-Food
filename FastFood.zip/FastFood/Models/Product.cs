using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FastFood.Models
{
    [Table("Products")]
    public class Product
    {
        [Key]
        [Display(Name = "Mã sản phẩm")]
        public int ProductId { get; set; }

        [Required(ErrorMessage = "Tên món ăn không được để trống")]
        [StringLength(150, ErrorMessage = "Tên món ăn không được vượt quá 150 ký tự")]
        [Display(Name = "Tên món ăn")]
        public string ProductName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Vui lòng chọn danh mục")]
        [Display(Name = "Danh mục")]
        public int CategoryId { get; set; }

        [Required(ErrorMessage = "Đơn giá không được để trống")]
        [Range(0, 100000000, ErrorMessage = "Đơn giá phải nằm trong khoảng 0 đến 100.000.000đ")]
        [Display(Name = "Đơn giá (VNĐ)")]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }

        [Range(0, 100000000, ErrorMessage = "Giá gốc phải nằm trong khoảng 0 đến 100.000.000đ")]
        [Display(Name = "Giá gốc / Giảm giá (VNĐ)")]
        [Column(TypeName = "decimal(18,2)")]
        public decimal? OldPrice { get; set; }

        [Required(ErrorMessage = "Số lượng tồn kho không được để trống")]
        [Range(0, 100000, ErrorMessage = "Số lượng tồn kho phải lớn hơn hoặc bằng 0")]
        [Display(Name = "Số lượng tồn")]
        public int Quantity { get; set; }

        [Display(Name = "Số lượng đã bán")]
        public int SoldQuantity { get; set; } = 0;

        [StringLength(500, ErrorMessage = "Đường dẫn hình ảnh không được vượt quá 500 ký tự")]
        [Display(Name = "Hình ảnh")]
        public string? ImageUrl { get; set; }

        [Display(Name = "Mô tả món ăn")]
        public string? Description { get; set; }

        [Range(0, 5, ErrorMessage = "Đánh giá từ 0 đến 5 sao")]
        [Display(Name = "Đánh giá sao")]
        public double Rating { get; set; } = 5.0;

        [Display(Name = "Món nổi bật")]
        public bool IsFeatured { get; set; } = false;

        [Display(Name = "Combo tiết kiệm")]
        public bool IsCombo { get; set; } = false;

        [ForeignKey("CategoryId")]
        [Display(Name = "Chủng loại")]
        public virtual Category? Category { get; set; }

        public virtual ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();
    }
}
