using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FastFood.Models
{
    [Table("Categories")]
    public class Category
    {
        [Key]
        [Display(Name = "Mã danh mục")]
        public int CategoryId { get; set; }

        [Required(ErrorMessage = "Tên danh mục không được để trống")]
        [StringLength(100, ErrorMessage = "Tên danh mục không được vượt quá 100 ký tự")]
        [Display(Name = "Tên danh mục")]
        public string CategoryName { get; set; } = string.Empty;

        [StringLength(255, ErrorMessage = "Mô tả không được vượt quá 255 ký tự")]
        [Display(Name = "Mô tả")]
        public string? Description { get; set; }

        [StringLength(50, ErrorMessage = "Biểu tượng không được vượt quá 50 ký tự")]
        [Display(Name = "Biểu tượng (Icon)")]
        public string? Icon { get; set; }

        public virtual ICollection<Product> Products { get; set; } = new List<Product>();
    }
}
