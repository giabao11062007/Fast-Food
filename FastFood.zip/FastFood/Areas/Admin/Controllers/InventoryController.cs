using FastFood.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FastFood.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class InventoryController : Controller
    {
        private readonly FastFoodContext _context;

        public InventoryController(FastFoodContext context)
        {
            _context = context;
        }

        // GET: /Admin/Inventory
        // Checklist: "Quản lý kho hàng: Thống kê hàng theo 2 phần: Danh sách hàng tồn, Danh sách hàng cần nhập.
        // Dựa trên trang Index của Product Detail, tạo Partial View theo số lượng tồn:
        // - Danh sách hàng tồn: số lượng tồn > 0
        // - Danh sách hàng cần nhập: số lượng tồn = 0" (0.25đ nâng cao)
        public async Task<IActionResult> Index()
        {
            var inStock = await _context.Products
                .Include(p => p.Category)
                .Where(p => p.Quantity > 0)
                .OrderBy(p => p.Quantity)
                .ToListAsync();

            var outOfStock = await _context.Products
                .Include(p => p.Category)
                .Where(p => p.Quantity == 0)
                .OrderBy(p => p.ProductName)
                .ToListAsync();

            var model = new InventoryViewModel
            {
                InStockProducts = inStock,
                OutOfStockProducts = outOfStock
            };

            return View(model);
        }
    }
}
