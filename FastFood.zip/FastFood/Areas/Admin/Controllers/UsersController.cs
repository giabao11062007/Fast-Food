using FastFood.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FastFood.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class UsersController : Controller
    {
        private readonly FastFoodContext _context;

        public UsersController(FastFoodContext context)
        {
            _context = context;
        }

        // GET: /Admin/Users
        // Checklist: "Quản lý người dùng: Trang Index: Chỉ lưu giữ danh sách người quản trị. Có thể Thêm/Sửa/Xóa tài khoản người quản trị.
        // Nếu bảng có < 5 cột thì bỏ chức năng Detail."
        public async Task<IActionResult> Index()
        {
            var admins = await _context.Users
                .Where(u => u.Role == "Admin")
                .OrderBy(u => u.UserId)
                .ToListAsync();

            return View(admins);
        }

        // GET: /Admin/Users/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Admin/Users/Create
        // Checklist: Data Annotation validation
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(User user)
        {
            user.Role = "Admin"; // Force role to Admin
            user.CreatedAt = DateTime.Now;

            if (await _context.Users.AnyAsync(u => u.Username.ToLower() == user.Username.Trim().ToLower()))
            {
                ModelState.AddModelError("Username", "Tên đăng nhập này đã tồn tại.");
            }

            if (await _context.Users.AnyAsync(u => u.Email.ToLower() == user.Email.Trim().ToLower()))
            {
                ModelState.AddModelError("Email", "Email này đã được sử dụng.");
            }

            if (ModelState.IsValid)
            {
                _context.Users.Add(user);
                await _context.SaveChangesAsync();
                TempData["Success"] = $"Thêm tài khoản quản trị '{user.Username}' thành công!";
                return RedirectToAction(nameof(Index));
            }

            TempData["Error"] = "Vui lòng kiểm tra lại thông tin nhập vào.";
            return View(user);
        }

        // GET: /Admin/Users/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var user = await _context.Users.FirstOrDefaultAsync(u => u.UserId == id && u.Role == "Admin");
            if (user == null) return NotFound();

            return View(user);
        }

        // POST: /Admin/Users/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, User user)
        {
            if (id != user.UserId) return NotFound();

            user.Role = "Admin";

            // Check duplicate email
            if (await _context.Users.AnyAsync(u => u.Email.ToLower() == user.Email.Trim().ToLower() && u.UserId != user.UserId))
            {
                ModelState.AddModelError("Email", "Email này đã được sử dụng bởi tài khoản khác.");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(user);
                    await _context.SaveChangesAsync();
                    TempData["Success"] = $"Cập nhật tài khoản quản trị '{user.Username}' thành công!";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Users.Any(e => e.UserId == user.UserId))
                        return NotFound();
                    else
                        throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(user);
        }

        // GET: /Admin/Users/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var user = await _context.Users.FirstOrDefaultAsync(u => u.UserId == id && u.Role == "Admin");
            if (user == null) return NotFound();

            return View(user);
        }

        // POST: /Admin/Users/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.UserId == id && u.Role == "Admin");
            if (user == null)
            {
                TempData["Error"] = "Không tìm thấy tài khoản quản trị để xóa.";
                return RedirectToAction(nameof(Index));
            }

            // Prevent deleting the last admin
            int adminCount = await _context.Users.CountAsync(u => u.Role == "Admin");
            if (adminCount <= 1)
            {
                TempData["Error"] = "Không thể xóa tài khoản quản trị duy nhất của hệ thống!";
                return RedirectToAction(nameof(Index));
            }

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();
            TempData["Success"] = $"Đã xóa tài khoản quản trị '{user.Username}' thành công!";
            return RedirectToAction(nameof(Index));
        }
    }
}
