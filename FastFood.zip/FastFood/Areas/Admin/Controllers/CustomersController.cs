using FastFood.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FastFood.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class CustomersController : Controller
    {
        private readonly FastFoodContext _context;

        public CustomersController(FastFoodContext context)
        {
            _context = context;
        }

        // GET: /Admin/Customers
        // Checklist: "Trang Index: lưu giữ danh sách khách hàng, không có nút Thêm/Sửa/Xóa"
        public async Task<IActionResult> Index()
        {
            var customers = await _context.Users
                .Include(u => u.Orders)
                .Where(u => u.Role == "Customer")
                .OrderByDescending(u => u.UserId)
                .ToListAsync();

            return View(customers);
        }

        // GET: /Admin/Customers/Details/5
        // Checklist: "Trang Detail: hiển thị thông tin khách hàng + danh sách đơn hàng của khách hàng.
        // Tạo Partial View cho trang Index của Order để nhúng Danh sách đơn hàng vào trang Detail của Customer" (0.25đ nâng cao)
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var customer = await _context.Users
                .Include(u => u.Orders)
                    .ThenInclude(o => o.OrderDetails)
                .FirstOrDefaultAsync(u => u.UserId == id && u.Role == "Customer");

            if (customer == null) return NotFound();

            return View(customer);
        }
    }
}
