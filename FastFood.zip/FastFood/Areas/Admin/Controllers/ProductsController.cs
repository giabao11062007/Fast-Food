using FastFood.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace FastFood.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class ProductsController : Controller
    {
        private readonly FastFoodContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public ProductsController(FastFoodContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment;
        }

        // GET: /Admin/Products
        // Checklist: "Trang Index: chỉ hiện 4-5 cột dữ liệu chính (tên, ảnh, giá, số lượng tồn, chủng loại)"
        public async Task<IActionResult> Index()
        {
            var products = await _context.Products
                .Include(p => p.Category)
                .OrderByDescending(p => p.ProductId)
                .ToListAsync();

            return View(products);
        }

        // GET: /Admin/Products/Details/5
        // Checklist: "Trang Detail: format giống trang Detail Product cho trang Customer (không có nút MUA HÀNG).
        // Tạo Partial View Detail Product để tái sử dụng cho cả 2 trang Admin và Customer"
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var product = await _context.Products
                .Include(p => p.Category)
                .FirstOrDefaultAsync(m => m.ProductId == id);

            if (product == null) return NotFound();

            ViewBag.ShowBuyButton = false; // ADMIN DETAIL: KHÔNG CÓ NÚT MUA HÀNG
            return View(product);
        }

        // GET: /Admin/Products/Create
        public IActionResult Create()
        {
            ViewBag.CategoryId = new SelectList(_context.Categories, "CategoryId", "CategoryName");
            return View();
        }

        // POST: /Admin/Products/Create
        // Checklist:
        // - Create/Edit: Data Annotation (độ dài, bắt buộc, kiểu dữ liệu, giá trị)
        // - Upload được ảnh sản phẩm (0.25đ nâng cao)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product, IFormFile? imageFile)
        {
            if (ModelState.IsValid)
            {
                // XỬ LÝ UPLOAD ẢNH SẢN PHẨM (Checklist nâng cao)
                if (imageFile != null && imageFile.Length > 0)
                {
                    string uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "images", "products");
                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    string uniqueFileName = Guid.NewGuid().ToString() + "_" + Path.GetFileName(imageFile.FileName);
                    string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await imageFile.CopyToAsync(fileStream);
                    }

                    product.ImageUrl = "/images/products/" + uniqueFileName;
                }
                else if (string.IsNullOrWhiteSpace(product.ImageUrl))
                {
                    product.ImageUrl = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&q=80";
                }

                _context.Products.Add(product);
                await _context.SaveChangesAsync();
                TempData["Success"] = $"Thêm món ăn '{product.ProductName}' thành công!";
                return RedirectToAction(nameof(Index));
            }

            ViewBag.CategoryId = new SelectList(_context.Categories, "CategoryId", "CategoryName", product.CategoryId);
            return View(product);
        }

        // GET: /Admin/Products/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var product = await _context.Products.FindAsync(id);
            if (product == null) return NotFound();

            ViewBag.CategoryId = new SelectList(_context.Categories, "CategoryId", "CategoryName", product.CategoryId);
            return View(product);
        }

        // POST: /Admin/Products/Edit/5
        // Checklist:
        // - Create/Edit: Data Annotation
        // - Upload được ảnh sản phẩm
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Product product, IFormFile? imageFile)
        {
            if (id != product.ProductId) return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    // XỬ LÝ UPLOAD ẢNH NẾU CÓ CHỌN FILE MỚI
                    if (imageFile != null && imageFile.Length > 0)
                    {
                        string uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "images", "products");
                        if (!Directory.Exists(uploadsFolder))
                        {
                            Directory.CreateDirectory(uploadsFolder);
                        }

                        string uniqueFileName = Guid.NewGuid().ToString() + "_" + Path.GetFileName(imageFile.FileName);
                        string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                        using (var fileStream = new FileStream(filePath, FileMode.Create))
                        {
                            await imageFile.CopyToAsync(fileStream);
                        }

                        product.ImageUrl = "/images/products/" + uniqueFileName;
                    }

                    _context.Update(product);
                    await _context.SaveChangesAsync();
                    TempData["Success"] = $"Cập nhật món ăn '{product.ProductName}' thành công!";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Products.Any(e => e.ProductId == product.ProductId))
                        return NotFound();
                    else
                        throw;
                }
                return RedirectToAction(nameof(Index));
            }

            ViewBag.CategoryId = new SelectList(_context.Categories, "CategoryId", "CategoryName", product.CategoryId);
            return View(product);
        }

        // GET: /Admin/Products/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var product = await _context.Products
                .Include(p => p.Category)
                .Include(p => p.OrderDetails)
                .FirstOrDefaultAsync(m => m.ProductId == id);

            if (product == null) return NotFound();

            return View(product);
        }

        // POST: /Admin/Products/Delete/5
        // Checklist: "Delete: đã kiểm tra ràng buộc dữ liệu (constraints) với các bảng liên quan chưa?"
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _context.Products
                .Include(p => p.OrderDetails)
                .FirstOrDefaultAsync(p => p.ProductId == id);

            if (product == null)
            {
                TempData["Error"] = "Không tìm thấy món ăn để xóa.";
                return RedirectToAction(nameof(Index));
            }

            // KIỂM TRA RÀNG BUỘC VỚI BẢNG ORDERDETAILS (Checklist yêu cầu)
            if (product.OrderDetails != null && product.OrderDetails.Any())
            {
                TempData["Error"] = $"Không thể xóa món ăn '{product.ProductName}' vì đã phát sinh trong {product.OrderDetails.Count} đơn hàng của khách hàng! Để bảo toàn lịch sử hóa đơn, bạn có thể chỉnh số lượng tồn về 0 thay vì xóa.";
                return RedirectToAction(nameof(Index));
            }

            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
            TempData["Success"] = $"Đã xóa món ăn '{product.ProductName}' thành công!";
            return RedirectToAction(nameof(Index));
        }
    }
}
