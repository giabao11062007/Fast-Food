using FastFood.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FastFood.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class OrdersController : Controller
    {
        private readonly FastFoodContext _context;

        public OrdersController(FastFoodContext context)
        {
            _context = context;
        }

        // GET: /Admin/Orders
        // Checklist: "Quản lý đơn hàng: Trang Index: lưu giữ danh sách đơn hàng, không có nút Thêm/Sửa/Xóa"
        public async Task<IActionResult> Index()
        {
            var orders = await _context.Orders
                .Include(o => o.User)
                .Include(o => o.OrderDetails)
                .OrderByDescending(o => o.OrderDate)
                .ToListAsync();

            return View(orders);
        }

        // GET: /Admin/Orders/Details/5
        // Checklist: "Trang Detail: hiển thị thông tin khách hàng + danh sách đơn hàng của khách hàng.
        // CSS để hiển thị giống như Hóa đơn mua hàng.
        // Tạo Partial View cho trang Index của Order Detail để nhúng Danh sách chi tiết đơn hàng vào trang Detail của Order." (0.25đ nâng cao)
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var order = await _context.Orders
                .Include(o => o.User)
                .Include(o => o.OrderDetails)
                    .ThenInclude(od => od.Product)
                        .ThenInclude(p => p!.Category)
                .FirstOrDefaultAsync(m => m.OrderId == id);

            if (order == null) return NotFound();

            return View(order);
        }

        // POST: /Admin/Orders/UpdateStatus
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateStatus(int orderId, string status)
        {
            var order = await _context.Orders.FindAsync(orderId);
            if (order != null)
            {
                order.Status = status;
                await _context.SaveChangesAsync();
                TempData["Success"] = $"Đã cập nhật trạng thái đơn hàng #{orderId} thành '{status}'.";
            }
            return RedirectToAction(nameof(Details), new { id = orderId });
        }
    }
}
