using FastFood.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FastFood.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class CategoriesController : Controller
    {
        private readonly FastFoodContext _context;

        public CategoriesController(FastFoodContext context)
        {
            _context = context;
        }

        // GET: /Admin/Categories
        // Checklist: "Index: có hiển thị tổng số HÀNG HÓA thuộc danh mục?" (0.25 điểm nâng cao)
        public async Task<IActionResult> Index()
        {
            var categories = await _context.Categories
                .Include(c => c.Products)
                .OrderBy(c => c.CategoryId)
                .ToListAsync();

            return View(categories);
        }

        // GET: /Admin/Categories/Details/5
        // Checklist: "Details: có chứa Danh sách sản phẩm liên quan (Product Category) không?" (0.25 điểm nâng cao)
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var category = await _context.Categories
                .Include(c => c.Products)
                .FirstOrDefaultAsync(c => c.CategoryId == id);

            if (category == null) return NotFound();

            return View(category);
        }

        // GET: /Admin/Categories/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Admin/Categories/Create
        // Checklist: "Create/Edit: đã kiểm tra dữ liệu nhập (Data Annotation)"
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Category category)
        {
            if (ModelState.IsValid)
            {
                _context.Categories.Add(category);
                await _context.SaveChangesAsync();
                TempData["Success"] = $"Thêm danh mục '{category.CategoryName}' thành công!";
                return RedirectToAction(nameof(Index));
            }
            TempData["Error"] = "Vui lòng kiểm tra lại thông tin nhập vào theo đúng quy định.";
            return View(category);
        }

        // GET: /Admin/Categories/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var category = await _context.Categories.FindAsync(id);
            if (category == null) return NotFound();

            return View(category);
        }

        // POST: /Admin/Categories/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Category category)
        {
            if (id != category.CategoryId) return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(category);
                    await _context.SaveChangesAsync();
                    TempData["Success"] = $"Cập nhật danh mục '{category.CategoryName}' thành công!";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Categories.Any(e => e.CategoryId == category.CategoryId))
                        return NotFound();
                    else
                        throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(category);
        }

        // GET: /Admin/Categories/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var category = await _context.Categories
                .Include(c => c.Products)
                .FirstOrDefaultAsync(m => m.CategoryId == id);

            if (category == null) return NotFound();

            return View(category);
        }

        // POST: /Admin/Categories/Delete/5
        // Checklist: "Delete: đã kiểm tra ràng buộc dữ liệu (constraints) với các bảng liên quan chưa?
        // if (x.y.ToList() == null) {các lệnh delete} else {return Content("nội dung thông báo lỗi");}"
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var category = await _context.Categories
                .Include(c => c.Products)
                .FirstOrDefaultAsync(c => c.CategoryId == id);

            if (category == null)
            {
                TempData["Error"] = "Không tìm thấy danh mục để xóa.";
                return RedirectToAction(nameof(Index));
            }

            // KIỂM TRA RÀNG BUỘC DỮ LIỆU VỚI BẢNG PRODUCTS (Checklist yêu cầu)
            if (category.Products != null && category.Products.Any())
            {
                TempData["Error"] = $"Không thể xóa danh mục '{category.CategoryName}' vì vẫn còn {category.Products.Count} sản phẩm trực thuộc! Vui lòng xóa hoặc chuyển sản phẩm trước khi xóa danh mục.";
                return RedirectToAction(nameof(Index));
            }

            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();
            TempData["Success"] = $"Đã xóa danh mục '{category.CategoryName}' thành công!";
            return RedirectToAction(nameof(Index));
        }
    }
}
