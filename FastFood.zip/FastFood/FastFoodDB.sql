-- =========================================================================
-- DATABASE SCRIPT CHO DỰ ÁN FASTFOOD STORE (ASP.NET CORE MVC & SQL SERVER)
-- =========================================================================

IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'FastFoodDB')
BEGIN
    CREATE DATABASE FastFoodDB;
END
GO

USE FastFoodDB;
GO

-- 1. BẢNG DANH MỤC (Categories)
IF OBJECT_ID('dbo.OrderDetails', 'U') IS NOT NULL DROP TABLE dbo.OrderDetails;
IF OBJECT_ID('dbo.Orders', 'U') IS NOT NULL DROP TABLE dbo.Orders;
IF OBJECT_ID('dbo.Products', 'U') IS NOT NULL DROP TABLE dbo.Products;
IF OBJECT_ID('dbo.Users', 'U') IS NOT NULL DROP TABLE dbo.Users;
IF OBJECT_ID('dbo.Categories', 'U') IS NOT NULL DROP TABLE dbo.Categories;
GO

CREATE TABLE dbo.Categories (
    CategoryId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    CategoryName NVARCHAR(100) NOT NULL,
    Description NVARCHAR(255) NULL,
    Icon NVARCHAR(50) NULL
);
GO

-- 2. BẢNG HÀNG HÓA / SẢN PHẨM (Products)
CREATE TABLE dbo.Products (
    ProductId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    ProductName NVARCHAR(150) NOT NULL,
    CategoryId INT NOT NULL,
    Price DECIMAL(18,2) NOT NULL,
    OldPrice DECIMAL(18,2) NULL,
    Quantity INT NOT NULL DEFAULT 0,            -- Số lượng tồn kho
    SoldQuantity INT NOT NULL DEFAULT 0,        -- Số lượng đã bán
    ImageUrl NVARCHAR(500) NULL,
    Description NVARCHAR(MAX) NULL,
    Rating FLOAT NOT NULL DEFAULT 5.0,
    IsFeatured BIT NOT NULL DEFAULT 0,          -- Món nổi bật
    IsCombo BIT NOT NULL DEFAULT 0,             -- Combo khuyến mãi
    CONSTRAINT FK_Products_Categories FOREIGN KEY (CategoryId) 
        REFERENCES dbo.Categories(CategoryId) ON DELETE NO ACTION
);
GO

-- 3. BẢNG NGƯỜI DÙNG / KHÁCH HÀNG & ADMIN (Users)
CREATE TABLE dbo.Users (
    UserId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    Username NVARCHAR(50) NOT NULL UNIQUE,
    Password NVARCHAR(100) NOT NULL,
    FullName NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100) NOT NULL,
    Phone NVARCHAR(20) NULL,
    Address NVARCHAR(255) NULL,
    Role NVARCHAR(20) NOT NULL DEFAULT 'Customer', -- 'Admin' hoặc 'Customer'
    CreatedAt DATETIME NOT NULL DEFAULT GETDATE()
);
GO

-- 4. BẢNG ĐƠN HÀNG (Orders)
CREATE TABLE dbo.Orders (
    OrderId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    UserId INT NOT NULL,
    OrderDate DATETIME NOT NULL DEFAULT GETDATE(),
    CustomerName NVARCHAR(100) NOT NULL,
    CustomerPhone NVARCHAR(20) NOT NULL,
    CustomerAddress NVARCHAR(255) NOT NULL,
    CustomerEmail NVARCHAR(100) NULL,
    DeliveryType NVARCHAR(50) NOT NULL DEFAULT N'Giao tận nơi (30 phút)',
    PaymentMethod NVARCHAR(50) NOT NULL DEFAULT N'Tiền mặt khi nhận hàng (COD)',
    Notes NVARCHAR(500) NULL,
    TotalAmount DECIMAL(18,2) NOT NULL,
    Status NVARCHAR(50) NOT NULL DEFAULT N'Đang xử lý',
    CONSTRAINT FK_Orders_Users FOREIGN KEY (UserId) 
        REFERENCES dbo.Users(UserId) ON DELETE NO ACTION
);
GO

-- 5. BẢNG CHI TIẾT ĐƠN HÀNG (OrderDetails)
CREATE TABLE dbo.OrderDetails (
    OrderDetailId INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    OrderId INT NOT NULL,
    ProductId INT NOT NULL,
    Quantity INT NOT NULL,
    UnitPrice DECIMAL(18,2) NOT NULL,
    CONSTRAINT FK_OrderDetails_Orders FOREIGN KEY (OrderId) 
        REFERENCES dbo.Orders(OrderId) ON DELETE CASCADE,
    CONSTRAINT FK_OrderDetails_Products FOREIGN KEY (ProductId) 
        REFERENCES dbo.Products(ProductId) ON DELETE NO ACTION
);
GO

-- =========================================================================
-- DỮ LIỆU MẪU (SEED DATA)
-- =========================================================================

-- Seed Categories
INSERT INTO dbo.Categories (CategoryName, Description, Icon) VALUES
(N'Burger', N'Bánh kẹp burger thơm ngon hảo hạng với bò Mỹ và phô mai', N'🍔'),
(N'Khoai Tây', N'Khoai tây chiên vàng giòn rụm với bơ và phô mai lắc', N'🍟'),
(N'Gà Rán', N'Gà tươi ướp đậm đà giòn cay chuẩn vị', N'🍗'),
(N'Pizza', N'Pizza nướng lò thơm lừng phô mai kéo sợi', N'🍕'),
(N'Đồ Uống', N'Nước giải khát mát lạnh sảng khoái', N'🥤'),
(N'Combo', N'Combo tiết kiệm đầy đủ món ăn và nước uống', N'🎁'),
(N'Tacos', N'Bánh kẹp kiểu Mexico giòn rụm nhân bò xé', N'🌮');
GO

-- Seed Users
INSERT INTO dbo.Users (Username, Password, FullName, Email, Phone, Address, Role, CreatedAt) VALUES
(N'admin', N'admin123', N'Quản Trị Viên Hệ Thống', N'admin@fastfood.vn', N'0909123456', N'Văn phòng FastFood Store, Q.1, TP.HCM', N'Admin', DATEADD(DAY, -30, GETDATE())),
(N'customer', N'customer123', N'Nguyễn Văn Khách', N'customer@gmail.com', N'0987654321', N'123 Đường Nguyễn Trãi, Phường Bến Thành, Quận 1, TP. Hồ Chí Minh', N'Customer', DATEADD(DAY, -20, GETDATE())),
(N'lethimy', N'customer123', N'Lê Thị Mỹ', N'lethimy@gmail.com', N'0912345678', N'456 Đường Lê Lợi, Quận 1, TP. Hồ Chí Minh', N'Customer', DATEADD(DAY, -15, GETDATE()));
GO

-- Seed Products
INSERT INTO dbo.Products (ProductName, CategoryId, Price, OldPrice, Quantity, SoldQuantity, ImageUrl, Description, Rating, IsFeatured, IsCombo) VALUES
(N'Double Beef Burger', 1, 59000, 75000, 45, 128, N'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&q=80', N'Hai lớp thịt bò Úc tươi thượng hạng nướng lửa hồng, kèm phô mai Cheddar chảy quyện, xà lách giòn và sốt đặc biệt bí truyền.', 5.0, 1, 0),
(N'Burger Gà Giòn Phô Mai', 1, 49000, 60000, 30, 85, N'https://images.unsplash.com/photo-1550547660-d9450f859349?w=600&q=80', N'Miếng ức gà chiên giòn rụm kết hợp sốt mayonnaise cay nhẹ và phô mai béo ngậy.', 4.8, 1, 0),
(N'Gà Rán Giòn Cay', 3, 45000, 55000, 50, 98, N'https://images.unsplash.com/photo-1626645738196-c2a7c87a8f58?w=600&q=80', N'Gà tươi ướp gia vị 12 loại thảo mộc, lớp vỏ chiên xù vàng óng giòn tan, thịt bên trong mềm ngọt mọng nước.', 4.9, 1, 0),
(N'Cánh Gà Sốt Chua Ngọt', 3, 52000, 65000, 25, 64, N'https://images.unsplash.com/photo-1567620832903-9fc6debc209f?w=600&q=80', N'Cánh gà chiên giòn đảo sốt chua ngọt đậm vị kiểu Hàn Quốc, rắc mè trắng rang thơm.', 4.7, 0, 0),
(N'Pizza 4 Phô Mai (Quattro)', 4, 89000, 110000, 20, 201, N'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=600&q=80', N'Đế pizza nướng củi giòn ngoài mềm trong, hòa quyện 4 loại phô mai hảo hạng: Mozzarella, Gorgonzola, Fontina và Parmesan.', 5.0, 1, 0),
(N'Pizza Hải Sản Nhiệt Đới', 4, 99000, 120000, 15, 115, N'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600&q=80', N'Tôm, mực, thanh cua tươi phủ sốt cà chua cay dịu và phô mai Mozzarella béo ngậy kèm dứa thơm lừng.', 4.8, 0, 0),
(N'Khoai Tây Chiên Bơ Tỏi', 2, 29000, 35000, 60, 76, N'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=600&q=80', N'Khoai tây cắt lát giòn rụm vàng ươm, lắc đều cùng bơ thực vật thơm lừng và sốt tỏi ớt hấp dẫn.', 4.6, 1, 0),
(N'Khoai Tây Lắc Phô Mai', 2, 32000, 40000, 40, 92, N'https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?w=600&q=80', N'Khoai tây chiên giòn rụm phủ lớp bột phô mai mặn ngọt đậm đà khó cưỡng.', 4.7, 0, 0),
(N'Coca-Cola Tươi Mát Lạnh', 5, 18000, 20000, 100, 320, N'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=600&q=80', N'Ly nước ngọt có gas mát lạnh sảng khoái với đá bi và lát chanh tươi.', 4.9, 0, 0),
(N'Trà Đào Cam Sả', 5, 28000, 35000, 35, 88, N'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=600&q=80', N'Hương vị trà đen đậm đà hòa quyện cùng tinh dầu sả, nước cốt cam tươi và những miếng đào giòn ngọt.', 4.8, 0, 0),
(N'Combo Burger Đôi', 6, 120000, 150000, 20, 140, N'https://images.unsplash.com/photo-1551782450-a2132b4ba21d?w=600&q=80', N'Bao gồm 2 Burger Bò Thượng Hạng + 2 Phần Khoai Tây Chiên Vàng + 2 Ly Coca-Cola Mát Lạnh (Tiết kiệm 20%).', 5.0, 0, 1),
(N'Combo Gia Đình Sung Túc', 6, 225000, 300000, 12, 60, N'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600&q=80', N'Bao gồm 1 Pizza lớn 4 Phô Mai + 4 Miếng Gà Rán Giòn Cay + 4 Ly Nước Ngọt (Tiết kiệm 25%).', 5.0, 0, 1),
(N'Combo Một Mình Thảnh Thơi', 6, 68000, 80000, 28, 110, N'https://images.unsplash.com/photo-1585032226651-759b368d7246?w=600&q=80', N'Bao gồm 1 Burger Bò / Gà tùy chọn + 1 Khoai Tây Nhỏ + 1 Ly Nước Ngọt (Tiết kiệm 15%).', 4.8, 0, 1),
(N'Tacos Bò Nướng Mexico', 7, 48000, 58000, 18, 45, N'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=600&q=80', N'Vỏ bánh bắp giòn rụm cuộn thịt bò xé ướp sốt salsa cà chua và phô mai kem béo ngậy.', 4.7, 0, 0),
(N'Burger Cá Tuyết Phô Mai', 1, 62000, 75000, 0, 95, N'https://images.unsplash.com/photo-1520072959219-c595dc870360?w=600&q=80', N'Phi lê cá tuyết Alaska lăn bột chiên xù, ăn kèm sốt Tartar và phô mai lá cao cấp (Tạm hết hàng).', 4.6, 0, 0),
(N'Gà Popcorn Lắc Rong Biển', 3, 38000, 45000, 0, 52, N'https://images.unsplash.com/photo-1562967914-608f82629710?w=600&q=80', N'Viên gà không xương chiên giòn cắn ngập miệng lắc bột rong biển thơm ngon (Tạm hết hàng).', 4.5, 0, 0);
GO

-- Seed Orders
INSERT INTO dbo.Orders (UserId, OrderDate, CustomerName, CustomerPhone, CustomerAddress, CustomerEmail, DeliveryType, PaymentMethod, Notes, TotalAmount, Status) VALUES
(2, DATEADD(DAY, -2, GETDATE()), N'Nguyễn Văn Khách', N'0987654321', N'123 Đường Nguyễn Trãi, Q.1', N'customer@gmail.com', N'Giao tận nơi (30 phút)', N'Tiền mặt khi nhận hàng (COD)', N'Giao lúc 12h trưa giúp mình nhé', 148000, N'Đã giao hàng'),
(2, DATEADD(HOUR, -5, GETDATE()), N'Nguyễn Văn Khách', N'0987654321', N'123 Đường Nguyễn Trãi, Q.1', N'customer@gmail.com', N'Giao tận nơi (30 phút)', N'Chuyển khoản ngân hàng', N'Ít đá, tương cà nhiều hơn tương ớt', 120000, N'Đang xử lý');
GO

-- Seed OrderDetails
INSERT INTO dbo.OrderDetails (OrderId, ProductId, Quantity, UnitPrice) VALUES
(1, 1, 1, 59000),
(1, 5, 1, 89000),
(2, 11, 1, 120000);
GO

PRINT N'Tạo Database và khởi tạo dữ liệu FastFoodDB thành công!';
GO
